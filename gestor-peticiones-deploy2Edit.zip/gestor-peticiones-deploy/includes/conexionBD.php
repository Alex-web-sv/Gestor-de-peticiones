<?php
function conectarBD()
{
    $servername = "192.168.2.49";
    $username = "jafet";
    $password = "ClaveJafet2026!";
    $dbname = "peticiones";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    return $conn;
}
