<?php
class Database
{
    private $servername = "192.168.2.49";
    private $username   = "jafet";
    private $password   = "ClaveJafet2026!";
    private $dbname     = "peticiones";
    private $conn;

    // Constructor: se ejecuta al crear el objeto
    public function __construct()
    {
        $this->connect();
    }

    // Método para conectar
    private function connect()
    {
        $this->conn = new mysqli(
            $this->servername,
            $this->username,
            $this->password,
            $this->dbname
        );

        if ($this->conn->connect_error) {
            die("Conexión fallida: " . $this->conn->connect_error);
        }
    }

    // Método para consultas preparadas (más seguro)
    public function prepare($sql)
    {
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            die("Error en la preparación: " . $this->conn->error);
        }
        return $stmt;
    }

    // Método para cerrar conexión
    public function close()
    {
        $this->conn->close();
    }
}
