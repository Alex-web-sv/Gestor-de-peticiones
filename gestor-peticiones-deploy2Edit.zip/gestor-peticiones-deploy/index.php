<?php
session_start();
require_once __DIR__ . '/includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $correo = $_POST['email'] ?? '';
  $password = $_POST['password'] ?? '';

  $rol = autenticarUsuario($correo, $password);

  if ($rol) {
    $_SESSION['usuario'] = $correo;
    $_SESSION['rol'] = $rol;

    if ($rol === 'ADM. SISTEMA') {
      header('Location: administrador.php');
      exit;
    } else {
      header('Location: usuarios.php');
      exit;
    }
  } else {
    $error = "Correo o contraseña incorrectos.";
  }
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Google+Sans+Flex:opsz,wght@6..144,1..1000&display=swap"
    rel="stylesheet" />
  <link rel="stylesheet" href="build/css/app.css" />
  <title>Gestor de Peticiones</title>
</head>

<body>
  <main class="contenido-principal contenedor">

    <div class="login">
      <div class="login-contenido">
        <div class="login-header">
          <img src="src/img/logo.png" alt="Logo construrama" />
          <h1>BIENVENIDO(A)</h1>
          <p>Ingresa tus datos</p>
        </div>
        <form action="" method="POST" class="formulario">
          <div class="formulario-correo entrada">
            <label for="email">Correo electrónico</label>
            <div class="formulario-input">
              <img
                src="src/img/mail_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.png"
                alt="mail" />
              <input name="email"
                class="correo-input"
                type="email"
                id="email"
                placeholder="correo@ejemplo.com"
                autocomplete="email" require />
            </div>
          </div>
          <div class="formulario-password entrada">
            <label for="password">Contraseña</label>
            <div class="formulario-input">
              <img
                src="src/img/lock_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.png"
                alt="lock" />
              <input name="password"
                class="password-input"
                type="password"
                id="password"
                placeholder="••••••••" require />
            </div>
          </div>
          <button type="submit">INICIAR SESIÓN</button>
          <div class="formulario-olvidar-password">
            <a href="#">¿Olvidaste tu contraseña?</a>
          </div>
        </form>
      </div>
    </div>
    <div class="portada">
      <div class="portada-circulo arriba-derecha"></div>
      <div class="portada-circulo abajo-izquierda"></div>
      <div class="portada-contenido">
        <div class="portada-contenido-separacion">
          <div class="portada-contenido-fondo">
            <img
              src="src/img/chat_paste_go_70dp_E3E3E3_FILL0_wght400_GRAD0_opsz48.png"
              alt="Logo construrama" />
          </div>
        </div>
        <h2>SISTEMA DE PETICIONES</h2>
        <p>Gestiona tus solicitudes de manera eficiente</p>
      </div>
    </div>
  </main>
  <footer class="footer">
    <p>©2026 CONSTRURAMA GRUPO ROCA - Todos los derechos reservados</p>
  </footer>
</body>

</html>