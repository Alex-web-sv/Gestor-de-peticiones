
/* ---------------------------
    Datos de ejemplo (reemplaza por fetch a tu API)
    Moneda: MX pesos (MX$)
    --------------------------- */
const datos = {
  "María González": {
    email: "maria.gonzalez@email.com",
    telefono: "+52 1 55 1234 5678",
    direccion: "Calle Principal 123, CDMX",
    pedidos: [
      { id: "PED-001", fecha: "27/01/2026", estado: "entregado", monto: 2500.50, pago: "Tarjeta", productos: [{nombre:"Laptop HP", precio:1800.00, qty:1},{nombre:"Mouse", precio:700.50, qty:1}] },
      { id: "PED-002", fecha: "23/01/2026", estado: "entregado", monto: 3500.00, pago: "PayPal", productos: [{nombre:"Monitor 24\"", precio:3500.00, qty:1}] }
    ]
  },
  "Juan Pérez": {
    email: "juan.perez@email.com",
    telefono: "+52 1 55 6000 1234",
    direccion: "Av. Secundaria 45, Guadalajara",
    pedidos: [
      { id: "PED-004", fecha: "30/01/2026", estado: "entregado", monto: 11400.00, pago: "Transferencia", productos: [{nombre:"PC Gamer", precio:11400.00, qty:1}] }
    ]
  },
  "Carlos Rodríguez": {
    email: "carlos.rodriguez@email.com",
    telefono: "+52 1 55 6456 7890",
    direccion: "Calle Sol 56, Monterrey",
    pedidos: [
      { id: "PED-020", fecha: "24/01/2026", estado: "entregado", monto: 6400.00, pago: "Tarjeta", productos: [{nombre:"Tablet", precio:6400.00, qty:1}] }
    ]
  }
};

/* ---------------------------
    Utilidades
    --------------------------- */
function formatMX(amount){
  return `MX$${Number(amount || 0).toFixed(2)}`;
}

function obtenerPedidosPlano(){
  const arr = [];
  Object.keys(datos).forEach(nombre=>{
    const cliente = datos[nombre];
    (cliente.pedidos || []).forEach(p=>{
      arr.push({...p, cliente: nombre});
    });
  });
  arr.sort((a,b)=>{
    const pa = a.fecha.split('/').reverse().join('-');
    const pb = b.fecha.split('/').reverse().join('-');
    return pb.localeCompare(pa);
  });
  return arr;
}

function construirClientes(){
  const arr = [];
  Object.keys(datos).forEach(nombre=>{
    const c = datos[nombre];
    const pedidos = c.pedidos || [];
    const totalPedidos = pedidos.length;
    const totalGastado = pedidos.reduce((s,p)=>s + (p.monto||0),0);
    const ultimo = pedidos.length ? pedidos[0].fecha : '—';
    arr.push({ nombre, email:c.email, telefono:c.telefono, direccion:c.direccion, totalPedidos, totalGastado, ultimo });
  });
  return arr;
}

/* ---------------------------
    Plantillas y renderers
    --------------------------- */

/* PEDIDOS */
function plantillaPedidosHTML(){
  return `
    <div>
      <div class="resumen mb-sm">
        <div class="card-resumen"><div class="label">Pedidos Totales</div><div class="valor" id="res_pedidosTotales">0</div><div class="small">Pedidos registrados</div></div>
        <div class="card-resumen"><div class="label">Entregados</div><div class="valor" id="res_entregados">0</div><div class="small">Pedidos entregados</div></div>
        <div class="card-resumen"><div class="label">Pendientes</div><div class="valor" id="res_pendientes">0</div><div class="small">En proceso</div></div>
      </div>

      <div class="pedidos-layout pedidos-modificado">
        <section class="panel">
          <h3>Pedidos recientes</h3>
          <div class="search">
            <input id="buscarPedido" type="search" placeholder="Buscar por ID, cliente o estado" aria-label="Buscar pedidos" class="search-input">
            <button class="btn" id="nuevoPedido">Nuevo</button>
          </div>
          <ul class="lista-pedidos" id="listaPedidos"></ul>
        </section>

        <section class="detalle" id="detallePedido">
          <div class="top">
            <div>
              <h2 id="detalleTitulo">Selecciona un pedido</h2>
              <div class="small" id="detalleSub">Ver detalles completos del pedido seleccionado</div>
            </div>
            <div id="estadoGrande"></div>
          </div>

          <div class="grid" id="detalleGrid">
            <div class="card-small cliente-info" id="clienteInfo">
              <h4 class="small">Cliente</h4>
              <p id="clienteNombre">—</p>
              <p id="clienteEmail" class="small">—</p>
              <p id="clienteTelefono" class="small">—</p>
              <p id="clienteDireccion" class="small">—</p>
            </div>

            <div class="card-small" id="resumenPedido">
              <h4 class="small">Resumen</h4>
              <p class="muted">Pedido: <strong id="pedidoId">—</strong></p>
              <p class="muted">Fecha: <strong id="pedidoFecha">—</strong></p>
              <p class="muted">Método de pago: <strong id="pedidoPago">—</strong></p>
              <div class="acciones-pedido" id="accionesPedido" hidden>
                <button class="btn" id="editarBtn">Editar</button>
                <button class="btn" id="actualizarBtn">Actualizar</button>
                <button class="btn" id="eliminarBtn">Eliminar</button>
              </div>
            </div>

            <div class="full-span">
              <h4 class="small">Productos</h4>
              <ul class="productos-list" id="productosList"></ul>
              <div class="totales mt-sm" id="totalesPedido">
                <div class="small">Subtotal: <span id="subtotal">MX$0.00</span></div>
                <div class="small">Total: <span id="total">MX$0.00</span></div>
              </div>
            </div>
          </div>
        </section>

        <aside class="col-der historial-ampliado">
          <div class="historial-pedidos">
            <h4>Historial de pedidos</h4>
            <input id="buscarHistorial" type="search" placeholder="Buscar historial..." class="search-input mt-sm">
            <ul id="listaHistorial"></ul>
          </div>
        </aside>
      </div>
    </div>
  `;
}

function renderPedidosView(){
  const workspace = document.getElementById('workspace');
  workspace.innerHTML = plantillaPedidosHTML();

  const pedidosPlano = obtenerPedidosPlano();
  const root = workspace;
  const listaPedidosEl = root.querySelector('#listaPedidos');
  const productosList = root.querySelector('#productosList');
  const detalleTitulo = root.querySelector('#detalleTitulo');
  const detalleSub = root.querySelector('#detalleSub');
  const estadoGrande = root.querySelector('#estadoGrande');
  const clienteNombre = root.querySelector('#clienteNombre');
  const clienteEmail = root.querySelector('#clienteEmail');
  const clienteTelefono = root.querySelector('#clienteTelefono');
  const clienteDireccion = root.querySelector('#clienteDireccion');
  const pedidoIdEl = root.querySelector('#pedidoId');
  const pedidoFechaEl = root.querySelector('#pedidoFecha');
  const pedidoPagoEl = root.querySelector('#pedidoPago');
  const accionesPedido = root.querySelector('#accionesPedido');

  root.querySelector('#res_pedidosTotales').textContent = pedidosPlano.length;
  root.querySelector('#res_entregados').textContent = pedidosPlano.filter(p=>p.estado==='entregado').length;
  root.querySelector('#res_pendientes').textContent = pedidosPlano.filter(p=>p.estado==='pendiente' || p.estado==='procesando').length;

  function renderLista(filter=''){
    listaPedidosEl.innerHTML = '';
    const f = filter.trim().toLowerCase();
    pedidosPlano.forEach(p=>{
      const text = `${p.id} ${p.cliente} ${p.estado} ${p.monto}`.toLowerCase();
      if (f && !text.includes(f)) return;
      const li = document.createElement('li');
      li.tabIndex = 0;
      li.dataset.id = p.id;
      li.innerHTML = `
        <div>
          <div class="pedido-id">${p.id}</div>
          <div class="pedido-meta small">${p.cliente} • ${p.fecha}</div>
        </div>
        <div class="pedido-meta-right">
          <div class="badge ${p.estado}">${p.estado.toUpperCase()}</div>
          <div class="small">${formatMX(p.monto)}</div>
        </div>
      `;
      li.addEventListener('click', ()=> seleccionarPedido(p.id, li));
      li.addEventListener('keydown', (e)=>{ if(e.key==='Enter') seleccionarPedido(p.id, li) });
      listaPedidosEl.appendChild(li);
    });
    if (!listaPedidosEl.children.length){
      listaPedidosEl.innerHTML = '<li class="small">No hay pedidos que coincidan</li>';
    }
  }

  function seleccionarPedido(id, liEl){
    Array.from(listaPedidosEl.children).forEach(ch=>ch.classList.remove('selected'));
    if (liEl) liEl.classList.add('selected');

    const pedido = pedidosPlano.find(x=>x.id===id);
    if (!pedido) return;
    detalleTitulo.textContent = `Pedido ${pedido.id}`;
    detalleSub.textContent = `${pedido.cliente} • ${pedido.fecha}`;
    estadoGrande.innerHTML = `<div class="estado-large ${pedido.estado}">${pedido.estado.toUpperCase()}</div>`;

    const cliente = datos[pedido.cliente];
    clienteNombre.textContent = pedido.cliente;
    clienteEmail.textContent = cliente?.email || '—';
    clienteTelefono.textContent = cliente?.telefono || '—';
    clienteDireccion.textContent = cliente?.direccion || '—';

    pedidoIdEl.textContent = pedido.id;
    pedidoFechaEl.textContent = pedido.fecha;
    pedidoPagoEl.textContent = pedido.pago || '—';

    productosList.innerHTML = '';
    let subtotal = 0;
    (pedido.productos || []).forEach(prod=>{
      const li = document.createElement('li');
      const totalProd = (prod.precio || 0) * (prod.qty || 1);
      subtotal += totalProd;
      li.innerHTML = `<div>${prod.nombre} <span class="small">x${prod.qty}</span></div><div>${formatMX(totalProd)}</div>`;
      productosList.appendChild(li);
    });
    if ((pedido.productos || []).length === 0){
      productosList.innerHTML = '<li class="small">No hay productos listados</li>';
    }
    root.querySelector('#subtotal').textContent = formatMX(subtotal);
    root.querySelector('#total').textContent = formatMX(pedido.monto || subtotal);

    accionesPedido.hidden = false;
  }

  function renderHistorial(){
    const listaHistorial = root.querySelector('#listaHistorial');
    listaHistorial.innerHTML = '';
    pedidosPlano.forEach(p=>{
      const li = document.createElement('li');
      li.innerHTML = `<div class="pedido-id">${p.id}</div><div class="small">${p.cliente} • ${p.fecha} • ${formatMX(p.monto)}</div><div class="small"><span class="badge ${p.estado}">${p.estado}</span></div>`;
      li.addEventListener('click', ()=> {
        const el = Array.from(listaPedidosEl.children).find(x=>x.dataset.id === p.id);
        if (el) el.click();
      });
      listaHistorial.appendChild(li);
    });
  }

  const buscarPedidoInput = root.querySelector('#buscarPedido');
  if (buscarPedidoInput) buscarPedidoInput.addEventListener('input', e=> renderLista(e.target.value));
  const buscarHistInput = root.querySelector('#buscarHistorial');
  if (buscarHistInput) buscarHistInput.addEventListener('input', e=>{
    const filtro = e.target.value.toLowerCase();
    Array.from(root.querySelector('#listaHistorial').children).forEach(li=>{
      li.style.display = li.textContent.toLowerCase().includes(filtro) ? '' : 'none';
    });
  });

  root.querySelector('#nuevoPedido').addEventListener('click', ()=> alert('Abrir formulario para crear nuevo pedido (ejemplo)'));
  root.querySelector('#editarBtn').addEventListener('click', ()=> alert('Editar pedido (ejemplo)'));
  root.querySelector('#actualizarBtn').addEventListener('click', ()=> alert('Actualizar pedido (ejemplo)'));
  root.querySelector('#eliminarBtn').addEventListener('click', ()=> {
    if (confirm('¿Eliminar este pedido?')) alert('Pedido eliminado (ejemplo)');
  });

  renderLista();
  renderHistorial();
  setTimeout(()=> {
    const first = listaPedidosEl.querySelector('li[data-id]');
    if (first) first.click();
  }, 150);
}

/* CLIENTES: directorio más pequeño, info más grande */
function plantillaClientesHTML(){
  return `
    <div>
      <div class="resumen mb-sm">
        <div class="card-resumen"><div class="label">Total Clientes</div><div class="valor" id="totalClientes">0</div><div class="small">Clientes registrados</div></div>
        <div class="card-resumen"><div class="label">Ventas Totales</div><div class="valor" id="ventasTotales">MX$0.00</div><div class="small">Ingresos acumulados</div></div>
        <div class="card-resumen"><div class="label">Pedidos Totales</div><div class="valor" id="pedidosTotales">0</div><div class="small">Pedidos registrados</div></div>
      </div>

      <div class="clientes-layout clientes-modificado">
        <section class="directorio expandido small-directorio">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <h3>Directorio</h3>
            <div class="flex">
              <input id="buscarClienteCenter" type="search" placeholder="Buscar..." class="search-input">
            </div>
          </div>

          <div class="overflow-auto mt-sm">
            <table class="tabla" id="tablaClientes">
              <thead>
                <tr><th>Nombre</th><th>Pedidos</th><th>Total</th></tr>
              </thead>
              <tbody id="tbodyClientes"></tbody>
            </table>
          </div>
        </section>

        <aside class="info-cliente expandido large-info" id="infoCliente">
          <h4>Información del Cliente</h4>
          <div class="mt-sm"><div class="small">Nombre</div><div id="infoNombre">—</div></div>
          <div class="mt-sm"><div class="small">Email</div><div id="infoEmail">—</div></div>
          <div class="mt-sm"><div class="small">Teléfono</div><div id="infoTelefono">—</div></div>
          <div class="mt-sm"><div class="small">Dirección</div><div id="infoDireccion">—</div></div>
          <hr>
          <div class="btn-row mt-sm">
            <div><div class="small">Total Pedidos</div><div id="infoTotalPedidos">0</div></div>
            <div><div class="small">Total Gastado</div><div id="infoTotalGastado">MX$0.00</div></div>
            <div><div class="small">Promedio</div><div id="infoPromedio">MX$0.00</div></div>
          </div>
          <div class="mt-sm" style="display:flex;gap:8px">
            <button class="btn" id="editarClienteBtn">Editar</button>
            <button class="btn" id="verPedidosClienteBtn">Ver pedidos</button>
          </div>
        </aside>
      </div>
    </div>
  `;
}

function renderClientesView(){
  const workspace = document.getElementById('workspace');
  workspace.innerHTML = plantillaClientesHTML();
  const root = workspace;

  let clientesArr = construirClientes();

  root.querySelector('#totalClientes').textContent = clientesArr.length;
  const ventas = clientesArr.reduce((s,c)=>s + c.totalGastado,0);
  root.querySelector('#ventasTotales').textContent = formatMX(ventas);
  const pedidosCount = clientesArr.reduce((s,c)=>s + c.totalPedidos,0);
  root.querySelector('#pedidosTotales').textContent = pedidosCount;

  const tbodyClientes = root.querySelector('#tbodyClientes');
  const buscarCenter = root.querySelector('#buscarClienteCenter');

  function renderTabla(filter=''){
    tbodyClientes.innerHTML = '';
    const f = filter.trim().toLowerCase();
    clientesArr.forEach(c=>{
      if (f && !(`${c.nombre} ${c.email} ${c.totalGastado}`.toLowerCase().includes(f))) return;
      const tr = document.createElement('tr');
      tr.innerHTML = `<td><strong>${c.nombre}</strong><div class="small">${c.email}</div></td><td>${c.totalPedidos}</td><td>${formatMX(c.totalGastado)}</td>`;
      tr.addEventListener('click', ()=> seleccionarCliente(c.nombre));
      tbodyClientes.appendChild(tr);
    });
    if (!tbodyClientes.children.length) tbodyClientes.innerHTML = '<tr><td colspan="3" class="small">No hay clientes que coincidan</td></tr>';
  }

  const infoNombre = root.querySelector('#infoNombre');
  const infoEmail = root.querySelector('#infoEmail');
  const infoTelefono = root.querySelector('#infoTelefono');
  const infoDireccion = root.querySelector('#infoDireccion');
  const infoTotalPedidos = root.querySelector('#infoTotalPedidos');
  const infoTotalGastado = root.querySelector('#infoTotalGastado');
  const infoPromedio = root.querySelector('#infoPromedio');
  const infoUltimoPedido = root.querySelector('#infoUltimoPedido');

  function seleccionarCliente(nombre){
    const c = datos[nombre];
    if (!c) return;
    const pedidos = c.pedidos || [];
    const totalPedidos = pedidos.length;
    const totalGastado = pedidos.reduce((s,p)=>s + (p.monto||0),0);
    const promedio = totalPedidos ? (totalGastado / totalPedidos) : 0;
    const ultimo = pedidos.length ? pedidos[0].fecha : '—';

    infoNombre.textContent = nombre;
    infoEmail.textContent = c.email || '—';
    infoTelefono.textContent = c.telefono || '—';
    infoDireccion.textContent = c.direccion || '—';
    infoTotalPedidos.textContent = totalPedidos;
    infoTotalGastado.textContent = formatMX(totalGastado);
    infoPromedio.textContent = formatMX(promedio);
    if (infoUltimoPedido) infoUltimoPedido.textContent = ultimo;
  }

  buscarCenter.addEventListener('input', e=> renderTabla(e.target.value));
  root.querySelector('#editarClienteBtn').addEventListener('click', ()=> alert('Editar cliente (ejemplo)'));
  root.querySelector('#verPedidosClienteBtn').addEventListener('click', ()=> alert('Mostrar pedidos del cliente (ejemplo)'));

  renderTabla();
  const firstName = clientesArr[0]?.nombre;
  if (firstName) seleccionarCliente(firstName);
}

/* REPORTES and CONFIG remain same structure but currency uses MX$ in displayed values */
function plantillaReportesHTML(){
  return `
    <div>
      <div class="resumen mb-sm">
        <div class="card-resumen"><div class="label">Resumen Mensual</div><div class="valor" id="resumenMes">enero 2026</div><div class="small" id="resumenPedidos">12 pedidos • MX$2605.98</div></div>
        <div class="card-resumen"><div class="label">Ingresos Totales</div><div class="valor" id="resIngresos">MX$0.00</div><div class="small">Periodo seleccionado</div></div>
        <div class="card-resumen"><div class="label">Pedidos Totales</div><div class="valor" id="resTotalPedidos">0</div><div class="small">Periodo seleccionado</div></div>
      </div>

      <div class="reportes-layout">
        <section class="reportes-center">
          <h3>Centro de Reportes</h3>

          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:12px">
            <div class="report-card">
              <h4>Reporte de Ventas</h4>
              <p>Resumen completo de todas las ventas del período seleccionado.</p>
              <div class="report-actions">
                <button class="btn-primary" data-report="ventas">Descargar PDF</button>
                <button class="btn" data-preview="ventas">Ver</button>
              </div>
            </div>

            <div class="report-card">
              <h4>Análisis de Clientes</h4>
              <p>Estadísticas detalladas de comportamiento de clientes.</p>
              <div class="report-actions">
                <button class="btn-accent" data-report="clientes">Descargar PDF</button>
                <button class="btn" data-preview="clientes">Ver</button>
              </div>
            </div>

            <div class="report-card">
              <h4>Reporte Mensual</h4>
              <p>Resumen de actividad mes a mes con comparativas.</p>
              <div class="report-actions">
                <button class="btn-success" data-report="mensual">Descargar PDF</button>
                <button class="btn" data-preview="mensual">Ver</button>
              </div>
            </div>
          </div>

          <div class="mt-sm flex" style="flex-wrap:wrap;align-items:center">
            <label class="small">Rango de fechas</label>
            <input type="month" id="mesInicio" />
            <button class="btn" id="generarReporte">Generar</button>
          </div>

          <div class="panel" style="margin-top:18px">
            <h4>Estadísticas</h4>
            <div id="estadisticasList" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-top:12px"></div>
          </div>
        </section>

        <aside style="display:flex;flex-direction:column;gap:12px">
          <div class="panel">
            <h4>Resumen Mensual</h4>
            <div class="monthly-summary mt-sm">
              <div class="summary-card">
                <div class="small">Mes</div>
                <div class="valor" id="mesLabel">enero 2026</div>
              </div>
              <div class="summary-card">
                <div class="small">Pedidos</div>
                <div class="valor" id="mesPedidos">12</div>
              </div>
              <div class="summary-card">
                <div class="small">Ingresos</div>
                <div class="valor" id="mesIngresos">MX$2605.98</div>
              </div>
            </div>
          </div>

          <div class="panel">
            <h4>Top 5 Clientes Frecuentes</h4>
            <ul class="top-clients" id="topClients"></ul>
          </div>
        </aside>
      </div>
    </div>
  `;
}

function renderReportesView(){
  const workspace = document.getElementById('workspace');
  workspace.innerHTML = plantillaReportesHTML();
  const root = workspace;

  const clientesArr = construirClientes();
  const pedidosPlano = obtenerPedidosPlano();

  const ingresos = pedidosPlano.reduce((s,p)=>s + (p.monto||0),0);
  root.querySelector('#resIngresos').textContent = formatMX(ingresos);
  root.querySelector('#resTotalPedidos').textContent = pedidosPlano.length;

  const top = clientesArr.slice().sort((a,b)=> b.totalPedidos - a.totalPedidos || b.totalGastado - a.totalGastado).slice(0,5);
  const topEl = root.querySelector('#topClients');
  topEl.innerHTML = '';
  top.forEach((c, i) => {
    const li = document.createElement('li');
    li.innerHTML = `<div><strong>${i+1}. ${c.nombre}</strong><div class="small">${c.totalPedidos} pedido(s)</div></div><div class="small">${formatMX(c.totalGastado)}</div>`;
    topEl.appendChild(li);
  });
  if (!top.length) topEl.innerHTML = '<li class="small">No hay datos</li>';

  const totalPedidos = pedidosPlano.length;
  const entregados = pedidosPlano.filter(p=>p.estado==='entregado').length;
  const pendientes = pedidosPlano.filter(p=>p.estado==='pendiente' || p.estado==='procesando').length;
  const promedio = totalPedidos ? (ingresos / totalPedidos) : 0;
  const clienteMayor = clientesArr.slice().sort((a,b)=> b.totalGastado - a.totalGastado)[0];

  const statsContainer = root.querySelector('#estadisticasList');
  statsContainer.innerHTML = `
    <div class="summary-card"><div class="small">Promedio por pedido</div><div class="valor">${formatMX(promedio)}</div></div>
    <div class="summary-card"><div class="small">Pedidos entregados</div><div class="valor">${entregados}</div></div>
    <div class="summary-card"><div class="small">Pedidos pendientes</div><div class="valor">${pendientes}</div></div>
    <div class="summary-card"><div class="small">Cliente mayor gasto</div><div class="valor">${clienteMayor ? clienteMayor.nombre : '—'}</div><div class="small">${clienteMayor ? formatMX(clienteMayor.totalGastado) : formatMX(0)}</div></div>
  `;

  root.querySelectorAll('[data-report]').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const tipo = btn.dataset.report;
      alert('Descargando ' + tipo + ' (ejemplo). Implementa la generación en el servidor.');
    });
  });
  root.querySelectorAll('[data-preview]').forEach(btn=>{
    btn.addEventListener('click', ()=> {
      const tipo = btn.dataset.preview;
      alert('Vista previa de ' + tipo + ' (ejemplo).');
    });
  });

  root.querySelector('#generarReporte').addEventListener('click', ()=>{
    const mes = root.querySelector('#mesInicio').value;
    if (!mes) {
      alert('Selecciona un mes.');
      return;
    }
    const [y,m] = mes.split('-');
    const meses = ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"];
    const label = `${meses[parseInt(m,10)-1] || m} ${y}`;
    root.querySelector('#mesLabel').textContent = label;
    const pedidosFiltrados = pedidosPlano.filter(p=>{
      const parts = p.fecha.split('/');
      const pMes = parts[1].padStart(2,'0');
      const pAnio = parts[2];
      return `${pAnio}-${pMes}` === mes;
    });
    const totalPedidos = pedidosFiltrados.length;
    const totalIngresos = pedidosFiltrados.reduce((s,p)=>s + (p.monto||0),0);
    root.querySelector('#mesPedidos').textContent = totalPedidos;
    root.querySelector('#mesIngresos').textContent = formatMX(totalIngresos);
    root.querySelector('#resumenMes').textContent = label;
    root.querySelector('#resumenPedidos').textContent = `${totalPedidos} pedidos • ${formatMX(totalIngresos)}`;
  });
}

/* CONFIGURACIÓN */
function plantillaConfiguracionHTML(){
  return `
    <div>
      <div class="resumen mb-sm">
        <div class="card-resumen"><div class="label">Ajustes</div><div class="valor">Sistema</div><div class="small">Preferencias y seguridad</div></div>
        <div class="card-resumen"><div class="label">Usuarios</div><div class="valor" id="configUsuariosCount">0</div><div class="small">Administrar cuentas</div></div>
        <div class="card-resumen"><div class="label">Backups</div><div class="valor">Automático</div><div class="small">Frecuencia configurada</div></div>
      </div>

      <div class="config-grid">
        <section class="config-panel">
          <h3>Configuración general</h3>

          <div class="config-section">
            <div class="form-row">
              <label>Nombre del sitio</label>
              <input type="text" id="siteName" class="input" value="Panel de administrador >:o">
            </div>

            <div class="form-row">
              <label>Zona horaria</label>
              <select id="timezone">
                <option value="UTC-6">UTC-6 (Central)</option>
                <option value="UTC+1">UTC+1 (Madrid)</option>
                <option value="UTC+0">UTC+0 (GMT)</option>
              </select>
            </div>

            <div class="form-row">
              <label>Idioma</label>
              <select id="locale">
                <option value="es-ES">Español (ES)</option>
                <option value="en-US">English (US)</option>
              </select>
            </div>

            <div class="form-row">
              <label>Formato moneda</label>
              <select id="currency">
                <option value="MXN">MXN (MX$)</option>
              </select>
            </div>
          </div>

          <hr>

          <h3>Notificaciones</h3>
          <div class="config-section">
            <div class="form-row">
              <label>Notificaciones por email</label>
              <div class="toggle"><input type="checkbox" id="notifEmail" checked> <span class="small-note">Enviar correos para nuevos pedidos y alertas</span></div>
            </div>
            <div class="form-row">
              <label>Notificaciones push</label>
              <div class="toggle"><input type="checkbox" id="notifPush"> <span class="small-note">Enviar notificaciones push a admins</span></div>
            </div>
            <div class="form-row">
              <label>Resumen diario</label>
              <select id="dailySummary">
                <option value="none">Desactivado</option>
                <option value="morning">Mañana</option>
                <option value="evening">Tarde</option>
              </select>
            </div>
          </div>

          <hr>

          <h3>Seguridad</h3>
          <div class="config-section">
            <div class="form-row">
              <label>Requerir 2FA</label>
              <div class="toggle"><input type="checkbox" id="require2fa"> <span class="small-note">Forzar autenticación de dos factores para administradores</span></div>
            </div>
            <div class="form-row">
              <label>Política de contraseñas</label>
              <select id="passwordPolicy">
                <option value="medium">Mínimo 8 caracteres</option>
                <option value="strong">Mínimo 10 caracteres + números</option>
                <option value="strict">12+ caracteres + números + símbolos</option>
              </select>
            </div>
            <div class="form-row">
              <label>Sesión expira</label>
              <select id="sessionTimeout">
                <option value="30">30 minutos</option>
                <option value="60">60 minutos</option>
                <option value="1440">24 horas</option>
              </select>
            </div>
          </div>

          <hr>

          <h3>Backup y datos</h3>
          <div class="config-section">
            <div class="form-row">
              <label>Frecuencia backup</label>
              <select id="backupFreq">
                <option value="daily">Diario</option>
                <option value="weekly">Semanal</option>
                <option value="monthly">Mensual</option>
              </select>
            </div>
            <div class="form-row">
              <label>Retención de datos</label>
              <select id="dataRetention">
                <option value="1y">1 año</option>
                <option value="3y">3 años</option>
                <option value="forever">Indefinido</option>
              </select>
            </div>
            <div class="form-row">
              <label>Backup manual</label>
              <button class="btn" id="backupNow">Crear copia ahora</button>
            </div>
          </div>

          <div class="btn-row mt-sm">
            <button class="btn-primary" id="saveConfig">Guardar cambios</button>
            <button class="btn" id="resetConfig">Restablecer valores</button>
          </div>
        </section>

        <aside class="config-panel registro-ampliado">
          <h4>Registro de actividad</h4>
          <div class="small-note">Últimas acciones del sistema</div>
          <div id="activityLog" class="activity-log-expanded"></div>
        </aside>
      </div>
    </div>
  `;
}

function renderConfiguracionView(){
  const workspace = document.getElementById('workspace');
  workspace.innerHTML = plantillaConfiguracionHTML();
  const root = workspace;

  const users = [
    { name: "Alejandro (admin)", email: "alejandro@ejemplo.com", role: "Administrador" },
    { name: "Lucía (editor)", email: "lucia@ejemplo.com", role: "Editor" }
  ];
  root.querySelector('#configUsuariosCount').textContent = users.length;

  const activityLog = root.querySelector('#activityLog');
  activityLog.innerHTML = '';
  const logs = [
    "02/02/2026 09:00 - Usuario Alejandro inició sesión",
    "01/02/2026 18:12 - Backup automático completado",
    "30/01/2026 14:05 - Usuario Lucía actualizó un pedido",
    "28/01/2026 11:22 - Se creó un nuevo usuario",
    "25/01/2026 08:10 - Exportación de clientes realizada"
  ];
  logs.forEach(l=>{
    const d = document.createElement('div');
    d.className = 'small';
    d.classList.add('mb-sm');
    d.textContent = l;
    activityLog.appendChild(d);
  });

  root.querySelector('#backupNow').addEventListener('click', ()=> {
    alert('Creando copia de seguridad (ejemplo). Implementa en servidor.');
  });
  root.querySelector('#saveConfig').addEventListener('click', ()=> {
    const cfg = {
      siteName: root.querySelector('#siteName').value,
      timezone: root.querySelector('#timezone').value,
      locale: root.querySelector('#locale').value,
      currency: root.querySelector('#currency').value,
      notifEmail: root.querySelector('#notifEmail').checked,
      notifPush: root.querySelector('#notifPush').checked,
      require2fa: root.querySelector('#require2fa').checked,
      passwordPolicy: root.querySelector('#passwordPolicy').value,
      sessionTimeout: root.querySelector('#sessionTimeout').value
    };
    console.log('Guardar configuración (ejemplo):', cfg);
    alert('Configuración guardada (ejemplo). Conecta a tu API para persistir cambios.');
  });
  root.querySelector('#resetConfig').addEventListener('click', ()=> {
    if (confirm('¿Restablecer valores por defecto?')) location.reload();
  });

  const addUserBtn = root.querySelector('#addUserBtn');
  if (addUserBtn) addUserBtn.addEventListener('click', ()=> {
    alert('Abrir modal para agregar usuario (ejemplo).');
  });
  const manageRolesBtn = root.querySelector('#manageRolesBtn');
  if (manageRolesBtn) manageRolesBtn.addEventListener('click', ()=> {
    alert('Abrir panel de roles (ejemplo).');
  });
}

/* ---------------------------
    Sidebar navegación
    --------------------------- */
const menuSidebar = document.getElementById('menuSidebar');
menuSidebar.addEventListener('click', (e)=>{
  const li = e.target.closest('li[data-section]');
  if (!li) return;
  Array.from(menuSidebar.querySelectorAll('li')).forEach(item => item.classList.remove('activo'));
  li.classList.add('activo');
  const section = li.dataset.section;
  if (section === 'pedidos') renderPedidosView();
  else if (section === 'clientes') renderClientesView();
  else if (section === 'reportes') renderReportesView();
  else if (section === 'configuracion') renderConfiguracionView();
});

menuSidebar.addEventListener('keydown', (e)=>{
  if (e.key === 'Enter' || e.key === ' ') {
    const li = e.target.closest('li[data-section]');
    if (!li) return;
    li.click();
    e.preventDefault();
  }
});

// Render inicial: Pedidos
renderPedidosView();
////////////////////////////////////////////////////////////

// <![CDATA[  <-- For SVG support
if ('WebSocket' in window) {
  (function () {
    function refreshCSS() {
      var sheets = [].slice.call(document.getElementsByTagName("link"));
      var head = document.getElementsByTagName("head")[0];
      for (var i = 0; i < sheets.length; ++i) {
        var elem = sheets[i];
        var parent = elem.parentElement || head;
        parent.removeChild(elem);
        var rel = elem.rel;
        if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
          var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
          elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
        }
        parent.appendChild(elem);
      }
    }
    var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
    var address = protocol + window.location.host + window.location.pathname + '/ws';
    var socket = new WebSocket(address);
    socket.onmessage = function (msg) {
      if (msg.data == 'reload') window.location.reload();
      else if (msg.data == 'refreshcss') refreshCSS();
    };
    if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
      console.log('Live reload enabled.');
      sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
    }
  })();
}
else {
  console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
}
// ]]>
