<?php
require_once __DIR__ . '/Database.php';

function autenticarUsuario($correo, $password)
{
    $db = new Database();

    // Consulta preparada para obtener la contraseña encriptada y el rol
    $sql = "SELECT u.contraseña, r.nombre_rol 
            FROM usuario u 
            INNER JOIN rol r ON u.rol_id = r.id_rol 
            WHERE u.correo = ? AND u.activo = 1";

    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificar si existe el usuario
    if ($result->num_rows === 1) {
        $usuario = $result->fetch_assoc();

        // Verificar contraseña encriptada
        if (password_verify($password, $usuario['contraseña'])) {
            return $usuario['nombre_rol'];
        }
    }

    return false;
}
