<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php');
    exit;
}

if ($_SESSION['rol'] !== 'ADM. SISTEMA') {
    header('Location: usuarios.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador del sistema</title>
</head>

<body>

</body>

</html>