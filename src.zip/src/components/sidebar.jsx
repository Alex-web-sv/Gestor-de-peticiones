import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { ChevronDown, ChevronRight } from "lucide-react"; // npm install lucide-react
import { navConfig } from "../config/menuconfig";

function Sidebar({ role, user }) {
  const location = useLocation();
  // Estado para controlar qué menús están abiertos
  const [openMenus, setOpenMenus] = useState({});

  const toggleMenu = (label) => {
    setOpenMenus((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  // 1. FILTRADO: Solo mostramos los módulos permitidos para este rol
  const visibleModules = navConfig.filter((module) => 
    module.roles.includes(role)
  );

  return (
    <aside className="w-72 bg-[#0f2b5a] text-slate-300 flex flex-col h-[calc(100vh-2rem)] sticky top-4 m-4 rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/5 transition-all">
      
      {/* Header */}
      <div className="p-8 flex items-center gap-4">
        <div className="bg-orange-600 w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg shadow-orange-900/20 shrink-0">
          <span className="text-white font-black text-xl tracking-tighter">PU</span>
        </div>
        <div>
          <h1 className="text-white font-bold text-lg leading-tight">Panel Usuario</h1>
          <p className="text-xs text-slate-400 capitalize">{role}</p>
        </div>
      </div>

      {/* Navegación Scrollable */}
      <nav className="flex-1 px-4 overflow-y-auto custom-scrollbar space-y-6 pb-6">
        
        {visibleModules.map((module) => (
          <div key={module.label}>
            {/* Título del Módulo (Ej. CONTABILIDAD) */}
            <div className="flex items-center gap-2 px-3 mb-3 text-orange-500">
               <module.icon size={18} />
               <p className="text-[14px] font-text uppercase tracking-[0.15em]">{module.label}</p>
            </div>

            {/* Submenús (Ej. Solicitudes / Soporte) */}
            <div className="space-y-2">
              {module.submenus.map((submenu) => {
                 const isOpen = openMenus[`${module.label}-${submenu.label}`];
                 
                 return (
                  <div key={submenu.label} className="bg-[#0a1e40]/50 rounded-2xl overflow-hidden">
                    {/* Botón Acordeón */}
                    <button 
                      onClick={() => toggleMenu(`${module.label}-${submenu.label}`)}
                      className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center gap-2 text-sm font-bold text-slate-200">
                        {submenu.icon && <submenu.icon size={16} className="text-slate-400"/>}
                        {submenu.label}
                      </div>
                      {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>

                    {/* Lista de Links (Se muestra si está abierto) */}
                    {isOpen && (
                      <div className="bg-[#081833] py-2 px-2 space-y-1">
                        {submenu.items.map((item) => {
                          const isActive = location.pathname === item.path;
                          return (
                            <Link
                              key={item.path}
                              to={item.path}
                              className={`block px-4 py-2 rounded-xl text-xs font-medium transition-all relative ${
                                isActive 
                                  ? "bg-orange-600 text-white shadow-md shadow-orange-900/20 pl-6" 
                                  : "text-slate-400 hover:text-white hover:bg-white/5 pl-6"
                              }`}
                            >
                              {/* Punto indicador si está activo */}
                              {isActive && <span className="absolute left-2 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-white rounded-full"></span>}
                              {item.label}
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                 );
              })}
            </div>
          </div>
        ))}
        
        {visibleModules.length === 0 && (
            <div className="text-center p-4 text-sm text-slate-500">
                No tienes módulos asignados.
            </div>
        )}

      </nav>

      {/* Footer User */}
      <div className="p-6 bg-slate-900/50 border-t border-slate-800/50">
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-800/30 border border-slate-700/30">
          <div className="w-10 h-10 rounded-xl bg-slate-700 flex items-center justify-center text-xs font-bold text-slate-300">
            {user.charAt(0)}
          </div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Activo</p>
            <p className="text-sm font-bold text-white truncate">{user}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;