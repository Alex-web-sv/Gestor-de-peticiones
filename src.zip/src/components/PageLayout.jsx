export default function PageLayout({ title, children }) {
  return (
    <div className="space-y-8 animate-in fade-in duration-500 w-full">
      
      {/* 1. ENCABEZADO (Igual que antes) */}
      <div className="flex justify-between items-center px-4 pt-2">
        <div>
           <h2 className="text-3xl font-bold text-slate-800 tracking-tight">{title}</h2>
           <div className="h-1 w-12 bg-orange-500 rounded-full mt-2"></div>
        </div>
        
        <button className="bg-orange-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-700 hover:scale-105 active:scale-95 transition-all flex items-center gap-2">
          <span>🔔</span> 
          <span className="hidden sm:inline">Notificaciones</span>
        </button>
      </div>

      {/* 2. ÁREA DE CONTENIDO (Lienzo Limpio) */}
      {/* Quitamos el 'bg-white' y el 'grid' forzado. 
          Ahora 'children' (tus formularios) ocuparán el espacio que necesiten.
      */}
      <div className="min-h-[500px]">
        {children || (
          // Mensaje por defecto si no hay contenido
          <div className="p-10 border-2 border-dashed border-slate-300 rounded-3xl text-center text-slate-400">
            Módulo configurado. Listo para recibir datos.
          </div>
        )}
      </div>

    </div>
  );
}