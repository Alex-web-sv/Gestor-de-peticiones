import { useState } from 'react';
import { Send, FileQuestion } from 'lucide-react';

export default function GenericRequest({ title, description }) {
  const [reason, setReason] = useState('');

  return (
    <div className="max-w-2xl mx-auto bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-200 text-center animate-in zoom-in-95">
        <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileQuestion size={40} />
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">{title}</h2>
        <p className="text-slate-500 mb-8">{description || "Complete el formulario para enviar su solicitud al departamento correspondiente."}</p>

        <div className="text-left space-y-4">
            <div>
                <label className="font-bold text-slate-700 ml-1">Detalle de la Solicitud</label>
                <textarea 
                    value={reason}
                    onChange={e => setReason(e.target.value)}
                    className="w-full mt-2 p-4 bg-slate-50 border border-slate-200 rounded-2xl h-40 outline-none focus:border-blue-500 transition-colors resize-none"
                    placeholder="Describa monto, litros, justificación o detalles necesarios..."
                ></textarea>
            </div>
            
            <button className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2">
                <Send size={20} /> Enviar Solicitud
            </button>
        </div>
    </div>
  );
}