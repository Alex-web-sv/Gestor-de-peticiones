import { useState } from 'react';
import { 
  Search, Trash2, FileText, AlertTriangle, X, 
  Calendar, CreditCard, User, Receipt
} from 'lucide-react';

export default function DeleteReceipts() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [deleteReason, setDeleteReason] = useState('');

  // Datos Simulados (Mock Data)
  const [receipts, setReceipts] = useState([
    { 
      id: 'REC-001', date: '2026-02-01', client: 'Constructora del Norte SA', 
      amount: 45000.00, method: 'Transferencia', status: 'active',
      invoices: ['F-2030', 'F-2031'] // Facturas que pagó este recibo
    },
    { 
      id: 'REC-002', date: '2026-02-02', client: 'Juan Pérez García', 
      amount: 2500.00, method: 'Efectivo', status: 'active',
      invoices: ['F-2045']
    },
    { 
      id: 'REC-003', date: '2026-02-03', client: 'Materiales Acapulco', 
      amount: 12800.50, method: 'Cheque', status: 'cancelled',
      invoices: ['F-2050']
    },
  ]);

  // Filtrado
  const filteredReceipts = receipts.filter(r => 
    r.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.client.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = () => {
    // Aquí iría tu lógica de Backend
    const updated = receipts.map(r => 
      r.id === selectedReceipt.id ? { ...r, status: 'cancelled' } : r
    );
    setReceipts(updated);
    setShowConfirm(false);
    setSelectedReceipt(null);
    setDeleteReason('');
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8 h-[calc(100vh-140px)]">
      
      {/* 1. LISTADO Y BÚSQUEDA (Izquierda) */}
      <div className="w-full lg:w-1/2 flex flex-col gap-6">
        
        {/* Buscador */}
        <div className="bg-white p-6 rounded-[2.5rem] shadow-sm border border-slate-200">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Search className="text-slate-400" /> Buscar Recibo
            </h3>
            <div className="relative">
                <input 
                    type="text" 
                    placeholder="Escribe el Folio (REC-001) o Cliente..." 
                    className="w-full pl-5 pr-12 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:border-red-500 focus:ring-4 focus:ring-red-500/10 outline-none transition-all font-medium text-lg"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>
        </div>

        {/* Lista de Resultados */}
        <div className="flex-1 bg-white rounded-[2.5rem] shadow-sm border border-slate-200 p-6 overflow-y-auto custom-scrollbar space-y-3">
            {filteredReceipts.map((receipt) => (
                <div 
                    key={receipt.id}
                    onClick={() => setSelectedReceipt(receipt)}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all flex justify-between items-center group ${
                        selectedReceipt?.id === receipt.id 
                            ? 'border-red-500 bg-red-50 ring-1 ring-red-200' 
                            : 'border-slate-100 hover:border-red-200 hover:bg-slate-50'
                    }`}
                >
                    <div className="flex gap-4 items-center">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${
                            receipt.status === 'cancelled' ? 'bg-slate-200 text-slate-400' : 'bg-red-100 text-red-600'
                        }`}>
                            <Receipt size={24} />
                        </div>
                        <div>
                            <h4 className={`font-bold ${receipt.status === 'cancelled' ? 'text-slate-400 line-through' : 'text-slate-800'}`}>
                                {receipt.id}
                            </h4>
                            <p className="text-sm text-slate-500">{receipt.client}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <p className={`font-bold ${receipt.status === 'cancelled' ? 'text-slate-400' : 'text-slate-800'}`}>
                            ${receipt.amount.toLocaleString()}
                        </p>
                        {receipt.status === 'cancelled' && (
                            <span className="text-[10px] font-bold text-slate-400 bg-slate-200 px-2 py-0.5 rounded-full">CANCELADO</span>
                        )}
                    </div>
                </div>
            ))}
            {filteredReceipts.length === 0 && (
                <div className="text-center py-10 text-slate-400">Sin resultados</div>
            )}
        </div>
      </div>

      {/* 2. DETALLE Y ACCIÓN (Derecha) */}
      <div className="w-full lg:w-1/2">
        {selectedReceipt ? (
            <div className="bg-white h-full rounded-[2.5rem] shadow-lg border border-red-100 p-8 flex flex-col relative overflow-hidden animate-in slide-in-from-right-5">
                
                {/* Fondo decorativo de alerta */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-bl-[100%] -mr-10 -mt-10 pointer-events-none"></div>

                <div className="flex justify-between items-start mb-8 relative z-10">
                    <div>
                        <span className="bg-red-100 text-red-700 font-bold px-3 py-1 rounded-lg text-xs tracking-wider uppercase">
                            Detalle del Recibo
                        </span>
                        <h2 className="text-3xl font-black text-slate-800 mt-3">{selectedReceipt.id}</h2>
                    </div>
                    <button onClick={() => setSelectedReceipt(null)} className="p-2 hover:bg-slate-100 rounded-full text-slate-400">
                        <X />
                    </button>
                </div>

                {/* Info Grid */}
                <div className="space-y-6 flex-1">
                    <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-4">
                        <div className="flex items-center gap-3">
                            <User className="text-slate-400" size={20}/>
                            <div>
                                <p className="text-xs text-slate-400 font-bold uppercase">Cliente</p>
                                <p className="font-bold text-slate-700">{selectedReceipt.client}</p>
                            </div>
                        </div>
                        <div className="h-px bg-slate-200"></div>
                        <div className="flex items-center gap-3">
                            <Calendar className="text-slate-400" size={20}/>
                            <div>
                                <p className="text-xs text-slate-400 font-bold uppercase">Fecha de Pago</p>
                                <p className="font-bold text-slate-700">{selectedReceipt.date}</p>
                            </div>
                        </div>
                        <div className="h-px bg-slate-200"></div>
                        <div className="flex items-center gap-3">
                            <CreditCard className="text-slate-400" size={20}/>
                            <div>
                                <p className="text-xs text-slate-400 font-bold uppercase">Método</p>
                                <p className="font-bold text-slate-700">{selectedReceipt.method}</p>
                            </div>
                        </div>
                    </div>

                    {/* Facturas Afectadas */}
                    <div>
                        <h4 className="font-bold text-slate-700 mb-3 flex items-center gap-2">
                            <FileText size={18} className="text-red-500"/> Facturas Afectadas
                        </h4>
                        <div className="flex flex-wrap gap-2">
                            {selectedReceipt.invoices.map(inv => (
                                <span key={inv} className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 font-mono text-sm shadow-sm">
                                    {inv}
                                </span>
                            ))}
                        </div>
                        <p className="text-xs text-slate-400 mt-2">
                            ⚠️ Al eliminar el recibo, el saldo de estas facturas volverá a "Pendiente de Pago".
                        </p>
                    </div>
                </div>

                {/* Botón de Acción */}
                <div className="mt-8 pt-8 border-t border-slate-100">
                    {selectedReceipt.status === 'active' ? (
                        <button 
                            onClick={() => setShowConfirm(true)}
                            className="w-full py-5 bg-red-600 hover:bg-red-700 text-white rounded-[2rem] font-bold text-lg shadow-xl shadow-red-600/20 transition-all flex items-center justify-center gap-3 group"
                        >
                            <Trash2 size={24} className="group-hover:scale-110 transition-transform" /> 
                            Eliminar Recibo
                        </button>
                    ) : (
                        <div className="w-full py-4 bg-slate-100 text-slate-400 rounded-[2rem] font-bold text-center border border-slate-200">
                            Recibo ya cancelado
                        </div>
                    )}
                </div>
            </div>
        ) : (
            // Estado Vacío (Placeholder Derecha)
            <div className="h-full border-2 border-dashed border-slate-200 rounded-[2.5rem] flex flex-col items-center justify-center text-slate-300 p-10 text-center">
                <Receipt size={64} className="mb-4 opacity-50" />
                <p className="font-bold text-xl">Selecciona un recibo</p>
                <p className="text-sm">Busca en la lista para ver detalles y opciones de eliminación.</p>
            </div>
        )}
      </div>

      {/* MODAL DE CONFIRMACIÓN */}
      {showConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl transform scale-100 transition-all">
                <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <AlertTriangle size={32} />
                </div>
                
                <h3 className="text-2xl font-black text-slate-800 text-center mb-2">¿Estás seguro?</h3>
                <p className="text-slate-500 text-center mb-6">
                    Estás a punto de eliminar el recibo <strong className="text-slate-800">{selectedReceipt?.id}</strong> por <strong className="text-slate-800">${selectedReceipt?.amount.toLocaleString()}</strong>.
                </p>

                <div className="mb-6">
                    <label className="text-xs font-bold text-slate-400 uppercase ml-3 mb-2 block">Motivo de cancelación</label>
                    <textarea 
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-slate-700 focus:border-red-500 outline-none resize-none h-24"
                        placeholder="Ej. Error en el monto, duplicado..."
                        value={deleteReason}
                        onChange={e => setDeleteReason(e.target.value)}
                        autoFocus
                    ></textarea>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <button 
                        onClick={() => setShowConfirm(false)}
                        className="py-4 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-colors"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={handleDelete}
                        disabled={!deleteReason.trim()}
                        className="py-4 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                        Confirmar
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
}