import { useState } from 'react';
import { Search, Save, TrendingUp, TrendingDown, History, AlertCircle, DollarSign } from 'lucide-react';

export default function PriceChange() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [newPrice, setNewPrice] = useState('');

  // Simulación de base de datos
  const mockProduct = {
    id: 1,
    name: "Cemento Gris Tolteca 50kg",
    sku: "CEM-G-50",
    cost: 180.00, // Costo interno
    currentPrice: 220.00, // Precio venta actual
    lastUpdate: "02/02/2026 por Juan Pérez",
    image: "https://via.placeholder.com/150" // Placeholder
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Aquí iría tu lógica real de búsqueda
    if(searchTerm.toLowerCase().includes('cemento')) {
        setSelectedProduct(mockProduct);
        setNewPrice(''); // Resetear input
    }
  };

  // Cálculos en tiempo real
  const calculateMargin = (price) => {
    if (!price || price <= 0) return 0;
    const margin = ((price - selectedProduct.cost) / price) * 100;
    return margin.toFixed(1);
  };

  const priceDiff = newPrice ? (parseFloat(newPrice) - selectedProduct?.currentPrice).toFixed(2) : 0;
  const currentMargin = selectedProduct ? calculateMargin(selectedProduct.currentPrice) : 0;
  const projectedMargin = selectedProduct && newPrice ? calculateMargin(parseFloat(newPrice)) : 0;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* 1. BARRA DE BÚSQUEDA (El punto de entrada) */}
      <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-200">
        <label className="block text-sm font-bold text-slate-700 mb-2 ml-2">Buscar Producto</label>
        <form onSubmit={handleSearch} className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-3.5 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Escribe SKU, Nombre o Código de Barras (ej. 'Cemento')" 
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 outline-none transition-all font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button type="submit" className="bg-slate-800 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-900 transition-colors">
            Buscar
          </button>
        </form>
      </div>

      {selectedProduct && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          
          {/* 2. TARJETA DE INFORMACIÓN DEL PRODUCTO (Izquierda) */}
          <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div>
                    <span className="bg-blue-100 text-blue-700 text-xs font-bold px-3 py-1 rounded-full">Inventario: 450 pzas</span>
                    <h2 className="text-2xl font-bold text-slate-800 mt-2">{selectedProduct.name}</h2>
                    <p className="text-slate-400 text-sm font-mono mt-1">SKU: {selectedProduct.sku}</p>
                </div>
                {/* Visualización rápida de ganancia actual */}
                <div className="text-right">
                    <p className="text-xs text-slate-400 font-bold uppercase">Margen Actual</p>
                    <p className={`text-2xl font-black ${currentMargin < 15 ? 'text-red-500' : 'text-green-500'}`}>
                        {currentMargin}%
                    </p>
                </div>
              </div>

              {/* Grid de Precios Actuales */}
              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                <div>
                    <p className="text-sm text-slate-500 mb-1">Costo Unitario</p>
                    <p className="text-xl font-bold text-slate-700">${selectedProduct.cost.toFixed(2)}</p>
                </div>
                <div>
                    <p className="text-sm text-slate-500 mb-1">Precio Público Actual</p>
                    <p className="text-xl font-bold text-slate-900">${selectedProduct.currentPrice.toFixed(2)}</p>
                </div>
              </div>
            </div>

            {/* Historial Mini */}
            <div className="mt-8 pt-6 border-t border-slate-100">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-3">
                    <History size={16} /> Última actualización
                </div>
                <p className="text-slate-600 font-medium bg-slate-50 px-4 py-2 rounded-lg inline-block text-sm">
                    {selectedProduct.lastUpdate}
                </p>
            </div>
          </div>

          {/* 3. PANEL DE ACCIÓN / MODIFICACIÓN (Derecha) */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-lg border border-orange-100 relative overflow-hidden">
            {/* Decoración de fondo */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-bl-[100%] -mr-10 -mt-10 pointer-events-none"></div>

            <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                <DollarSign className="text-orange-500" size={24}/> Nuevo Precio
            </h3>

            <div className="space-y-6">
                <div>
                    <label className="block text-sm font-bold text-slate-600 mb-2">Precio Final (Público)</label>
                    <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-lg">$</span>
                        <input 
                            type="number" 
                            value={newPrice}
                            onChange={(e) => setNewPrice(e.target.value)}
                            className="w-full pl-10 pr-4 py-4 bg-white border-2 border-orange-100 rounded-2xl text-3xl font-bold text-slate-800 focus:border-orange-500 focus:ring-4 focus:ring-orange-500/20 outline-none transition-all placeholder:text-slate-200"
                            placeholder="0.00"
                            autoFocus
                        />
                    </div>
                </div>

                {/* Simulador de Impacto */}
                {newPrice && (
                    <div className={`p-5 rounded-2xl border ${projectedMargin < 15 ? 'bg-red-50 border-red-100' : 'bg-green-50 border-green-100'}`}>
                        <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium text-slate-600">Nuevo Margen:</span>
                            <span className={`font-bold ${projectedMargin < 15 ? 'text-red-600' : 'text-green-600'}`}>
                                {projectedMargin}%
                            </span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-slate-600">Diferencia:</span>
                            <span className={`font-bold flex items-center gap-1 ${priceDiff > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {priceDiff > 0 ? <TrendingUp size={16}/> : <TrendingDown size={16}/>}
                                ${Math.abs(priceDiff)}
                            </span>
                        </div>
                        {projectedMargin < 10 && (
                             <div className="mt-3 flex items-start gap-2 text-xs text-red-600 font-medium">
                                <AlertCircle size={14} className="shrink-0 mt-0.5" />
                                <span>Cuidado: El margen es muy bajo.</span>
                             </div>
                        )}
                    </div>
                )}

                <button 
                    disabled={!newPrice}
                    className="w-full bg-orange-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-orange-600/30 hover:bg-orange-700 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:shadow-none flex justify-center items-center gap-2"
                >
                    <Save size={20} /> Guardar Cambio
                </button>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}