import { useState } from 'react';
import { 
  Search, User, Building2, MapPin, Phone, Mail, 
  CreditCard, Save, CheckCircle2, AlertCircle, RefreshCw 
} from 'lucide-react';

export default function AltaCliente() {
  const [mode, setMode] = useState('create'); // 'create' | 'edit'
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  // Estado del Formulario
  const [formData, setFormData] = useState({
    type: 'fisica', // 'fisica' | 'moral'
    rfc: '',
    name: '',
    email: '',
    phone: '',
    address: '',
    creditLimit: 0,
    daysCredit: 30
  });

  // Base de datos simulada para probar el buscador
  const mockClients = [
    { id: 1, type: 'fisica', rfc: 'XAXX010101000', name: 'Juan Pérez', email: 'juan@gmail.com', phone: '5551234567', address: 'Av. Reforma 123', creditLimit: 50000, daysCredit: 15 },
    { id: 2, type: 'moral', rfc: 'GHI901010ABC', name: 'Grupo Constructor del Sur', email: 'contacto@gcs.com', phone: '7441230909', address: 'Blvd. Naciones 45', creditLimit: 250000, daysCredit: 60 },
  ];

  // --- LÓGICA DE INTERACCIÓN ---

  const handleSearch = (e) => {
    e.preventDefault();
    const found = mockClients.find(c => 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      c.rfc.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (found) {
      setMode('edit');
      setFormData(found);
      showNotification('success', 'Cliente encontrado. Modo Edición activado.');
    } else {
      showNotification('error', 'Cliente no encontrado.');
    }
  };

  const handleReset = () => {
    setMode('create');
    setFormData({ type: 'fisica', rfc: '', name: '', email: '', phone: '', address: '', creditLimit: 0, daysCredit: 30 });
    setSearchTerm('');
    showNotification('info', 'Formulario limpio para Nuevo Cliente.');
  };

  const handleSave = () => {
    setLoading(true);
    // Simular guardado
    setTimeout(() => {
      setLoading(false);
      showNotification('success', mode === 'create' ? 'Cliente creado exitosamente.' : 'Cambios guardados correctamente.');
    }, 1500);
  };

  const showNotification = (type, msg) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 4000);
  };

  // Validación visual del RFC en tiempo real
  const isRfcValid = () => {
    const len = formData.rfc.length;
    if (formData.type === 'fisica') return len === 13;
    if (formData.type === 'moral') return len === 12;
    return false;
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      
      {/* 1. BARRA SUPERIOR DE BÚSQUEDA */}
      <div className="bg-white p-4 rounded-[2rem] shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 justify-between items-center">
        
        {/* Buscador */}
        <form onSubmit={handleSearch} className="relative w-full md:w-1/2">
            <Search className="absolute left-4 top-3.5 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Buscar para editar (Nombre o RFC)..." 
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 outline-none transition-all font-medium text-slate-600"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
        </form>

        {/* Botón Reset/Nuevo */}
        <button 
          onClick={handleReset}
          className="flex items-center gap-2 px-6 py-3 bg-blue-50 text-blue-700 font-bold rounded-xl hover:bg-blue-100 transition-colors"
        >
          <RefreshCw size={18} /> Limpiar / Nuevo
        </button>
      </div>

      {/* NOTIFICACIÓN FLOTANTE */}
      {notification && (
        <div className={`fixed bottom-8 right-8 px-6 py-4 rounded-xl shadow-2xl text-white font-bold animate-in slide-in-from-bottom-5 z-50 flex items-center gap-3 ${
            notification.type === 'success' ? 'bg-green-600' : notification.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        }`}>
            {notification.type === 'success' ? <CheckCircle2 /> : <AlertCircle />}
            {notification.msg}
        </div>
      )}

      {/* 2. FORMULARIO PRINCIPAL (GRID) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-500">
        
        {/* COLUMNA IZQUIERDA: DATOS DE IDENTIDAD */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200">
          
          <div className="flex items-center gap-4 mb-8">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-white shadow-lg ${mode === 'create' ? 'bg-green-500 shadow-green-200' : 'bg-orange-500 shadow-orange-200'}`}>
                {mode === 'create' ? <User size={32} /> : <RefreshCw size={32} />}
            </div>
            <div>
                <h2 className="text-2xl font-bold text-slate-800">
                    {mode === 'create' ? 'Nuevo Cliente' : 'Editando Cliente'}
                </h2>
                <p className="text-slate-400 text-sm">Información fiscal y de contacto</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Toggle Tipo de Persona */}
            <div className="md:col-span-2 flex gap-2 p-1 bg-slate-100 rounded-xl w-fit">
                <button 
                    onClick={() => setFormData({...formData, type: 'fisica'})}
                    className={`px-6 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${formData.type === 'fisica' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <User size={16} /> Persona Física
                </button>
                <button 
                    onClick={() => setFormData({...formData, type: 'moral'})}
                    className={`px-6 py-2 rounded-lg text-sm font-bold transition-all flex items-center gap-2 ${formData.type === 'moral' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <Building2 size={16} /> Persona Moral
                </button>
            </div>

            {/* Input Nombre */}
            <div className="md:col-span-2">
                <label className="text-xs font-bold text-slate-500 uppercase ml-2 mb-1 block">Nombre / Razón Social</label>
                <input 
                    type="text" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all font-medium text-lg"
                    placeholder={formData.type === 'fisica' ? "Ej. Juan Pérez García" : "Ej. Constructora del Pacífico S.A."}
                />
            </div>

            {/* Input RFC con Validación Visual */}
            <div className="relative">
                <label className="text-xs font-bold text-slate-500 uppercase ml-2 mb-1 block">RFC</label>
                <input 
                    type="text" 
                    value={formData.rfc}
                    onChange={e => setFormData({...formData, rfc: e.target.value.toUpperCase()})}
                    className={`w-full px-5 py-3 bg-slate-50 border rounded-xl outline-none transition-all font-mono uppercase ${
                        formData.rfc.length > 0 ? (isRfcValid() ? 'border-green-300 focus:border-green-500 text-green-700' : 'border-red-300 focus:border-red-500 text-red-700') : 'border-slate-200 focus:border-blue-500'
                    }`}
                    placeholder="XAXX010101000"
                    maxLength={13}
                />
                <div className="absolute right-4 top-9">
                    {formData.rfc.length > 0 && (
                        isRfcValid() ? <CheckCircle2 size={20} className="text-green-500" /> : <AlertCircle size={20} className="text-red-500" />
                    )}
                </div>
            </div>

            {/* Input Teléfono */}
            <div>
                <label className="text-xs font-bold text-slate-500 uppercase ml-2 mb-1 block">Teléfono</label>
                <div className="relative">
                    <Phone className="absolute left-4 top-3.5 text-slate-400" size={18} />
                    <input 
                        type="tel" 
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                        className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 outline-none transition-all"
                        placeholder="(744) 000-0000"
                    />
                </div>
            </div>

            {/* Input Dirección */}
            <div className="md:col-span-2">
                <label className="text-xs font-bold text-slate-500 uppercase ml-2 mb-1 block">Dirección Fiscal</label>
                <div className="relative">
                    <MapPin className="absolute left-4 top-3.5 text-slate-400" size={18} />
                    <input 
                        type="text" 
                        value={formData.address}
                        onChange={e => setFormData({...formData, address: e.target.value})}
                        className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:border-blue-500 outline-none transition-all"
                        placeholder="Calle, Número, Colonia, CP, Ciudad..."
                    />
                </div>
            </div>

          </div>
        </div>

        {/* COLUMNA DERECHA: CONFIGURACIÓN COMERCIAL (Interactivo) */}
        <div className="space-y-6">
            
            {/* Tarjeta Oscura de Crédito */}
            <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-bl-[100%] pointer-events-none"></div>
                
                <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                    <CreditCard className="text-orange-500" /> Configuración de Crédito
                </h3>

                <div className="space-y-6 relative z-10">
                    
                    {/* Slider de Crédito */}
                    <div>
                        <div className="flex justify-between text-sm mb-2 text-slate-300">
                            <span>Límite de Crédito</span>
                            <span className="font-bold text-white text-lg">${formData.creditLimit.toLocaleString()}</span>
                        </div>
                        <input 
                            type="range" 
                            min="0" 
                            max="500000" 
                            step="5000"
                            value={formData.creditLimit}
                            onChange={(e) => setFormData({...formData, creditLimit: parseInt(e.target.value)})}
                            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-500 hover:accent-orange-400 transition-all"
                        />
                        <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-bold uppercase">
                            <span>Contado ($0)</span>
                            <span>Mayorista ($500k)</span>
                        </div>
                    </div>

                    {/* Botones de Días de Crédito */}
                    <div className="bg-white/10 p-4 rounded-xl border border-white/5">
                        <label className="text-xs font-bold text-slate-300 uppercase block mb-3">Días de Crédito</label>
                        <div className="flex gap-2">
                            {[0, 15, 30, 60].map(day => (
                                <button
                                    key={day}
                                    onClick={() => setFormData({...formData, daysCredit: day})}
                                    className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${
                                        formData.daysCredit === day 
                                        ? 'bg-orange-600 text-white shadow-lg' 
                                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                    }`}
                                >
                                    {day === 0 ? '0' : day}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Botón Principal de Guardado */}
            <button 
                onClick={handleSave}
                disabled={loading || !formData.name}
                className="w-full py-5 bg-orange-600 text-white rounded-[2rem] font-bold text-lg shadow-lg shadow-orange-600/30 hover:bg-orange-700 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-3"
            >
                {loading ? (
                    <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></span>
                ) : (
                    <>
                        <Save size={24} /> 
                        {mode === 'create' ? 'Registrar Cliente' : 'Guardar Cambios'}
                    </>
                )}
            </button>

        </div>
      </div>
    </div>
  );
}