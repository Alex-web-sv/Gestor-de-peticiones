import { useState } from 'react';
import { Search, Package, ArrowRight, Save, Trash2, AlertTriangle, FileText, Plus } from 'lucide-react';

export default function InventoryOperations({ title, type }) {
  // type puede ser: 'ajuste', 'traspaso', 'compra', 'merma', 'produccion'
  
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState([]);
  
  // Base de datos simulada
  const mockProducts = [
    { id: 1, sku: 'CEM-50', name: 'Cemento Gris 50kg', stock: 400 },
    { id: 2, sku: 'VAR-38', name: 'Varilla 3/8', stock: 1200 },
    { id: 3, sku: 'PINT-B', name: 'Pintura Blanca 19L', stock: 50 },
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    // Simular encontrar producto y agregarlo
    const found = mockProducts.find(p => p.sku.toLowerCase().includes(searchTerm.toLowerCase()));
    if (found) {
        // Si ya existe, aumentar cantidad
        const exists = cart.find(item => item.id === found.id);
        if (exists) {
            setCart(cart.map(item => item.id === found.id ? {...item, qty: item.qty + 1} : item));
        } else {
            setCart([...cart, { ...found, qty: 1 }]);
        }
        setSearchTerm('');
    }
  };

  const updateQty = (id, delta) => {
    setCart(cart.map(item => {
        if (item.id === id) {
            const newQty = Math.max(1, item.qty + delta);
            return { ...item, qty: newQty };
        }
        return item;
    }));
  };

  const removeItem = (id) => setCart(cart.filter(item => item.id !== id));

  const getThemeColor = () => {
    switch(type) {
        case 'merma': return 'bg-red-600';     // Rojo para pérdidas
        case 'compra': return 'bg-green-600';  // Verde para entradas
        case 'traspaso': return 'bg-blue-600'; // Azul para movimientos
        default: return 'bg-orange-600';       // Naranja por defecto
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-140px)] animate-in fade-in">
      
      {/* IZQUIERDA: BUSCADOR Y LISTA DE PRODUCTOS */}
      <div className="flex-1 bg-white rounded-[2.5rem] shadow-sm border border-slate-200 flex flex-col overflow-hidden">
         <div className="p-6 border-b border-slate-100">
            <h3 className="text-xl font-bold text-slate-800 mb-2">{title}</h3>
            <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-4 top-3.5 text-slate-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Escanear SKU o buscar producto..." 
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-200 outline-none font-bold"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    autoFocus
                />
            </form>
         </div>

         <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {cart.length === 0 ? (
                <div className="text-center py-20 text-slate-300">
                    <Package size={64} className="mx-auto mb-4 opacity-50"/>
                    <p>Escanea productos para comenzar</p>
                </div>
            ) : (
                cart.map(item => (
                    <div key={item.id} className="flex justify-between items-center p-4 bg-slate-50 rounded-2xl border border-slate-100">
                        <div>
                            <p className="font-bold text-slate-700">{item.name}</p>
                            <p className="text-xs text-slate-400">SKU: {item.sku} | Stock: {item.stock}</p>
                        </div>
                        <div className="flex items-center gap-4">
                            <div className="flex items-center bg-white rounded-xl border border-slate-200 overflow-hidden">
                                <button onClick={() => updateQty(item.id, -1)} className="px-3 py-2 hover:bg-slate-100 font-bold text-slate-500">-</button>
                                <span className="w-12 text-center font-bold text-slate-800">{item.qty}</span>
                                <button onClick={() => updateQty(item.id, 1)} className="px-3 py-2 hover:bg-slate-100 font-bold text-slate-500">+</button>
                            </div>
                            <button onClick={() => removeItem(item.id)} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={18}/></button>
                        </div>
                    </div>
                ))
            )}
         </div>
      </div>

      {/* DERECHA: RESUMEN Y ACCIÓN */}
      <div className="lg:w-1/3 bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-xl flex flex-col justify-between">
         <div>
            <div className={`w-12 h-12 ${getThemeColor()} rounded-2xl flex items-center justify-center mb-6 text-white shadow-lg`}>
                <FileText size={24} />
            </div>
            <h2 className="text-2xl font-bold mb-1">Resumen de {title}</h2>
            <p className="text-slate-400 text-sm mb-8">
                {type === 'traspaso' ? 'Movimiento entre almacenes' : type === 'merma' ? 'Salida por daño/pérdida' : 'Actualización de stock'}
            </p>

            <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-white/10 rounded-xl border border-white/5">
                    <span className="text-slate-300">Total Artículos</span>
                    <span className="text-2xl font-bold">{cart.length}</span>
                </div>
                
                <div className="flex justify-between items-center p-4 bg-white/10 rounded-xl border border-white/5">
                    <span className="text-slate-300">Total Unidades</span>
                    <span className="text-2xl font-bold text-orange-400">{cart.reduce((acc, el) => acc + el.qty, 0)}</span>
                </div>

                {/* Campos extra según tipo */}
                {type === 'traspaso' && (
                    <div>
                        <label className="text-xs text-slate-400 font-bold uppercase mb-1 block">Destino</label>
                        <select className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white outline-none">
                            <option>Almacén Central</option>
                            <option>Sucursal Norte</option>
                            <option>Patio 2</option>
                        </select>
                    </div>
                )}

                <div>
                    <label className="text-xs text-slate-400 font-bold uppercase mb-1 block">Observaciones / Motivo</label>
                    <textarea className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white outline-none h-24 resize-none" placeholder="Escribe detalles..."></textarea>
                </div>
            </div>
         </div>

         <button 
            disabled={cart.length === 0}
            className={`w-full py-4 ${getThemeColor()} rounded-xl font-bold text-lg shadow-lg shadow-orange-900/40 hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2`}
         >
            <Save size={20} /> Procesar {title}
         </button>
      </div>

    </div>
  );
}