
// Exportamos las funciones reutilizables "Las 4 Grandes"
export { default as AltaCliente } from './AltaCliente';
export { default as CambioPrecio } from './CambioPrecio';
export { default as Hardware } from './Hardware';
export { default as ModificacionProducto } from './ModificacionProducto';

// Exportamos las funciones financieras
export { default as BankMovements } from './BankMovements';
export { default as DeleteReceipts } from './DeleteReceipts';

// Exportamos las funciones operativas (La Navaja Suiza)
export { default as InventoryOperations } from './InventoryOperations';

// Exportamos las solicitudes simples
export { default as GenericRequest } from './GenericRequest';