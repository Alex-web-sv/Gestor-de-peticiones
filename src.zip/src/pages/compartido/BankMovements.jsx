import { useState } from 'react';
import { 
  Search, Filter, Calendar, ArrowUpRight, ArrowDownLeft, 
  MoreVertical, Trash2, Edit2, AlertTriangle, X, Check, Save
} from 'lucide-react';

export default function BankMovements() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMov, setSelectedMov] = useState(null); // Para editar
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null); // ID para borrar

  // Datos simulados (Mock Data)
  const [movements, setMovements] = useState([
    { id: 1, date: '2026-02-01', concept: 'Pago Proveedor Aceros', ref: 'SPEI-9988', amount: -15400.00, type: 'expense', account: 'BBVA **** 1234', status: 'active' },
    { id: 2, date: '2026-02-02', concept: 'Venta Mostrador #4021', ref: 'DEP-EFECTIVO', amount: 8500.50, type: 'income', account: 'Banamex **** 5678', status: 'active' },
    { id: 3, date: '2026-02-03', concept: 'Comisión Bancaria', ref: 'COM-FEB', amount: -580.00, type: 'expense', account: 'BBVA **** 1234', status: 'active' },
    { id: 4, date: '2026-02-03', concept: 'Transferencia equivocada', ref: 'ERR-01', amount: 100.00, type: 'income', account: 'BBVA **** 1234', status: 'cancelled' },
  ]);

  // Manejo de Edición
  const handleEdit = (mov) => {
    setSelectedMov({ ...mov }); // Copia para no mutar directo
  };

  const handleSaveEdit = () => {
    // Aquí iría tu lógica de Backend
    setMovements(movements.map(m => m.id === selectedMov.id ? selectedMov : m));
    setSelectedMov(null);
  };

  // Manejo de Eliminación (Anulación)
  const handleDelete = (id) => {
    setMovements(movements.map(m => m.id === id ? { ...m, status: 'cancelled' } : m));
    setShowDeleteConfirm(null);
  };

  // Filtrado simple
  const filteredMovements = movements.filter(m => 
    m.concept.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.ref.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.amount.toString().includes(searchTerm)
  );

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-140px)]">
      
      {/* 1. LISTADO DE MOVIMIENTOS (Izquierda) */}
      <div className={`bg-white rounded-[2.5rem] shadow-sm border border-slate-200 flex flex-col overflow-hidden transition-all duration-300 ${selectedMov ? 'lg:w-2/3' : 'w-full'}`}>
        
        {/* Header del Listado */}
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-50/50">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Movimientos</h3>
            <p className="text-sm text-slate-400">Selecciona para editar o anular</p>
          </div>
          
          <div className="flex gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-none">
                <Search className="absolute left-3 top-2.5 text-slate-400" size={18}/>
                <input 
                    type="text" 
                    placeholder="Buscar referencia, monto..." 
                    className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 outline-none w-full"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                />
            </div>
            <button className="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">
                <Filter size={18} />
            </button>
          </div>
        </div>

        {/* Tabla / Lista */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {filteredMovements.map((mov) => (
                <div 
                    key={mov.id} 
                    className={`group relative p-4 rounded-2xl border transition-all cursor-pointer hover:shadow-md ${
                        mov.status === 'cancelled' 
                            ? 'bg-slate-50 border-slate-100 opacity-60 grayscale' 
                            : 'bg-white border-slate-100 hover:border-blue-200'
                    } ${selectedMov?.id === mov.id ? 'ring-2 ring-blue-500 border-transparent' : ''}`}
                    onClick={() => mov.status !== 'cancelled' && handleEdit(mov)}
                >
                    <div className="flex justify-between items-start">
                        <div className="flex gap-3">
                            {/* Icono Tipo */}
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                                mov.type === 'income' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                            }`}>
                                {mov.type === 'income' ? <ArrowDownLeft size={20}/> : <ArrowUpRight size={20}/>}
                            </div>
                            
                            <div>
                                <h4 className={`font-bold text-slate-700 ${mov.status === 'cancelled' ? 'line-through' : ''}`}>
                                    {mov.concept}
                                </h4>
                                <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                                    <span className="flex items-center gap-1"><Calendar size={12}/> {mov.date}</span>
                                    <span>•</span>
                                    <span className="font-mono">{mov.ref}</span>
                                    <span>•</span>
                                    <span>{mov.account}</span>
                                </div>
                            </div>
                        </div>

                        <div className="text-right">
                            <p className={`font-bold text-lg ${mov.type === 'income' ? 'text-green-600' : 'text-slate-800'}`}>
                                {mov.type === 'expense' && '-'} ${Math.abs(mov.amount).toLocaleString()}
                            </p>
                            {mov.status === 'cancelled' && (
                                <span className="bg-red-100 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded-full">CANCELADO</span>
                            )}
                        </div>
                    </div>

                    {/* Botón Borrar (Solo aparece en hover y si no está cancelado) */}
                    {mov.status !== 'cancelled' && (
                        <button 
                            onClick={(e) => {
                                e.stopPropagation(); // Evita abrir el editor
                                setShowDeleteConfirm(mov.id);
                            }}
                            className="absolute right-4 top-12 opacity-0 group-hover:opacity-100 transition-opacity p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                            title="Anular Movimiento"
                        >
                            <Trash2 size={18} />
                        </button>
                    )}
                </div>
            ))}
            
            {filteredMovements.length === 0 && (
                <div className="text-center py-10 text-slate-400">No se encontraron movimientos.</div>
            )}
        </div>
      </div>

      {/* 2. PANEL DE EDICIÓN (Derecha - Condicional) */}
      {selectedMov && (
        <div className="lg:w-1/3 bg-slate-900 text-white rounded-[2.5rem] p-8 shadow-xl flex flex-col animate-in slide-in-from-right-10 duration-300 relative overflow-hidden">
            {/* Fondo Decorativo */}
            <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-bl-[100%] pointer-events-none"></div>

            <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold flex items-center gap-2">
                    <Edit2 className="text-orange-500" size={20}/> Editar Movimiento
                </h3>
                <button onClick={() => setSelectedMov(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                    <X size={20} />
                </button>
            </div>

            <div className="space-y-5 flex-1 overflow-y-auto custom-scrollbar">
                
                {/* Monto (Generalmente Read-Only o advertencia) */}
                <div className="bg-white/10 p-4 rounded-2xl border border-white/5 text-center">
                    <p className="text-slate-400 text-xs uppercase mb-1">Monto Original</p>
                    <p className={`text-3xl font-bold ${selectedMov.type === 'income' ? 'text-green-400' : 'text-white'}`}>
                        ${Math.abs(selectedMov.amount).toLocaleString()}
                    </p>
                </div>

                <div>
                    <label className="text-slate-400 text-xs font-bold uppercase ml-2 mb-1 block">Concepto / Descripción</label>
                    <input 
                        type="text" 
                        value={selectedMov.concept}
                        onChange={(e) => setSelectedMov({...selectedMov, concept: e.target.value})}
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white focus:border-orange-500 focus:outline-none transition-colors"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-slate-400 text-xs font-bold uppercase ml-2 mb-1 block">Referencia</label>
                        <input 
                            type="text" 
                            value={selectedMov.ref}
                            onChange={(e) => setSelectedMov({...selectedMov, ref: e.target.value})}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white focus:border-orange-500 focus:outline-none"
                        />
                    </div>
                    <div>
                        <label className="text-slate-400 text-xs font-bold uppercase ml-2 mb-1 block">Fecha</label>
                        <input 
                            type="date" 
                            value={selectedMov.date}
                            onChange={(e) => setSelectedMov({...selectedMov, date: e.target.value})}
                            className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white focus:border-orange-500 focus:outline-none"
                        />
                    </div>
                </div>

                <div>
                    <label className="text-slate-400 text-xs font-bold uppercase ml-2 mb-1 block">Motivo del Cambio (Auditoría)</label>
                    <textarea 
                        className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white focus:border-orange-500 focus:outline-none h-24 resize-none"
                        placeholder="Escribe por qué estás modificando este registro..."
                    ></textarea>
                </div>

            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
                <button 
                    onClick={handleSaveEdit}
                    className="w-full py-4 bg-orange-600 hover:bg-orange-700 rounded-xl font-bold text-white shadow-lg shadow-orange-900/50 transition-all flex justify-center items-center gap-2"
                >
                    <Save size={20} /> Guardar Cambios
                </button>
            </div>
        </div>
      )}

      {/* MODAL DE CONFIRMACIÓN DE BORRADO */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
            <div className="bg-white rounded-[2rem] p-8 max-w-sm w-full shadow-2xl text-center">
                <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertTriangle size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">¿Anular Movimiento?</h3>
                <p className="text-slate-500 text-sm mb-6">
                    Esta acción no se puede deshacer. El movimiento quedará registrado como "Cancelado" y afectará el saldo final.
                </p>
                <div className="flex gap-3">
                    <button 
                        onClick={() => setShowDeleteConfirm(null)}
                        className="flex-1 py-3 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200"
                    >
                        Cancelar
                    </button>
                    <button 
                        onClick={() => handleDelete(showDeleteConfirm)}
                        className="flex-1 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200"
                    >
                        Sí, Anular
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
}