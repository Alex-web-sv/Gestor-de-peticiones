import { useState } from 'react';
import { 
  Search, Package, Tag, DollarSign, Layers, 
  BarChart3, Image as ImageIcon, Save, RefreshCw, 
  AlertCircle, CheckCircle2 
} from 'lucide-react';

export default function ModificacionProducto() {
  const [mode, setMode] = useState('create'); // 'create' | 'edit'
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  // Estado del Producto
  const [formData, setFormData] = useState({
    sku: '',
    name: '',
    category: 'Materiales',
    cost: 0,
    margin: 30, // % de ganancia por defecto
    price: 0,
    stock: 0,
    minStock: 10,
    supplier: '',
    description: ''
  });

  // Base de datos simulada
  const mockProducts = [
    { id: 1, sku: 'CEM-TOL-50', name: 'Cemento Gris Tolteca 50kg', category: 'Materiales', cost: 180, margin: 22.2, price: 220, stock: 450, minStock: 50, supplier: 'Cemex', description: 'Saco de cemento gris estándar.' },
    { id: 2, sku: 'VAR-3/8', name: 'Varilla Corrugada 3/8', category: 'Aceros', cost: 145, margin: 15, price: 166.75, stock: 1200, minStock: 200, supplier: 'Aceros de México', description: 'Varilla de alta resistencia.' },
  ];

  // --- LÓGICA ---

  // Cálculo automático de precio al cambiar Costo o Margen
  const updatePrice = (cost, margin) => {
    const c = parseFloat(cost) || 0;
    const m = parseFloat(margin) || 0;
    // Fórmula: Precio = Costo / (1 - (Margen/100)) para margen real
    // O Fórmula simple: Precio = Costo * (1 + (Margen/100))
    // Usaremos la simple para este ejemplo:
    const price = c * (1 + (m / 100));
    setFormData(prev => ({ ...prev, cost: c, margin: m, price: parseFloat(price.toFixed(2)) }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const found = mockProducts.find(p => 
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (found) {
      setMode('edit');
      setFormData(found);
      showNotification('success', 'Producto cargado para edición.');
    } else {
      showNotification('error', 'Producto no encontrado.');
    }
  };

  const handleReset = () => {
    setMode('create');
    setFormData({ sku: '', name: '', category: 'Materiales', cost: 0, margin: 30, price: 0, stock: 0, minStock: 10, supplier: '', description: '' });
    setSearchTerm('');
    showNotification('info', 'Formulario limpio.');
  };

  const handleSave = () => {
    if (!formData.name || !formData.sku) {
        showNotification('error', 'Faltan datos obligatorios (Nombre o SKU).');
        return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      showNotification('success', mode === 'create' ? 'Producto registrado correctamente.' : 'Producto actualizado.');
    }, 1500);
  };

  const showNotification = (type, msg) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 4000);
  };

  return (
    <div className="flex flex-col gap-6 h-[calc(100vh-140px)]">
      
      {/* 1. BARRA SUPERIOR */}
      <div className="bg-white p-4 rounded-[2rem] shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 justify-between items-center shrink-0">
        <form onSubmit={handleSearch} className="relative w-full md:w-1/2">
            <Search className="absolute left-4 top-3.5 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Buscar por SKU o Nombre..." 
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-blue-500 transition-all font-medium"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
        </form>
        <button onClick={handleReset} className="flex items-center gap-2 px-6 py-3 bg-blue-50 text-blue-700 font-bold rounded-xl hover:bg-blue-100 transition-colors">
          <RefreshCw size={18} /> Nuevo Producto
        </button>
      </div>

      {/* NOTIFICACIÓN */}
      {notification && (
        <div className={`fixed bottom-8 right-8 px-6 py-4 rounded-xl shadow-2xl text-white font-bold animate-in slide-in-from-bottom-5 z-50 flex items-center gap-3 ${
            notification.type === 'success' ? 'bg-green-600' : notification.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        }`}>
            {notification.type === 'success' ? <CheckCircle2 /> : <AlertCircle />}
            {notification.msg}
        </div>
      )}

      {/* 2. ÁREA DE TRABAJO (Scrollable) */}
      <div className="flex-1 overflow-y-auto custom-scrollbar space-y-6 pb-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* COLUMNA IZQ: INFO BÁSICA + IMAGEN */}
            <div className="lg:col-span-2 space-y-6">
                
                {/* Tarjeta Identidad */}
                <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
                            <Package size={24} />
                        </div>
                        <h3 className="text-xl font-bold text-slate-800">Información General</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Nombre del Producto</label>
                            <input 
                                type="text" 
                                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none font-bold text-lg text-slate-700"
                                placeholder="Ej. Cemento Gris Tolteca 50kg"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                            />
                        </div>

                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">SKU / Código</label>
                            <div className="relative">
                                <Tag className="absolute left-4 top-4 text-slate-400" size={18} />
                                <input 
                                    type="text" 
                                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none font-mono uppercase"
                                    placeholder="XXX-000"
                                    value={formData.sku}
                                    onChange={e => setFormData({...formData, sku: e.target.value.toUpperCase()})}
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Categoría</label>
                            <select 
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none"
                                value={formData.category}
                                onChange={e => setFormData({...formData, category: e.target.value})}
                            >
                                <option>Materiales</option>
                                <option>Aceros</option>
                                <option>Acabados</option>
                                <option>Plomería</option>
                                <option>Herramientas</option>
                            </select>
                        </div>

                        <div className="md:col-span-2">
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Descripción (Opcional)</label>
                            <textarea 
                                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 outline-none resize-none h-24"
                                placeholder="Detalles técnicos, medidas, etc."
                                value={formData.description}
                                onChange={e => setFormData({...formData, description: e.target.value})}
                            ></textarea>
                        </div>
                    </div>
                </div>

                {/* Tarjeta Inventario */}
                <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-200">
                    <div className="flex items-center gap-4 mb-6">
                        <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
                            <Layers size={24} />
                        </div>
                        <h3 className="text-xl font-bold text-slate-800">Control de Inventario</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Stock Actual</label>
                            <input 
                                type="number" 
                                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-700"
                                value={formData.stock}
                                onChange={e => setFormData({...formData, stock: parseInt(e.target.value) || 0})}
                            />
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Stock Mínimo</label>
                            <input 
                                type="number" 
                                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                                value={formData.minStock}
                                onChange={e => setFormData({...formData, minStock: parseInt(e.target.value) || 0})}
                            />
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-2 mb-1 block">Proveedor</label>
                            <input 
                                type="text" 
                                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl"
                                placeholder="Nombre Prov."
                                value={formData.supplier}
                                onChange={e => setFormData({...formData, supplier: e.target.value})}
                            />
                        </div>
                    </div>
                </div>

            </div>

            {/* COLUMNA DER: PRECIOS Y GUARDAR */}
            <div className="space-y-6">
                
                {/* Calculadora de Precio */}
                <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-bl-[100%] pointer-events-none"></div>
                    
                    <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                        <DollarSign className="text-green-400" /> Configuración de Precio
                    </h3>

                    <div className="space-y-5 relative z-10">
                        <div>
                            <label className="text-slate-400 text-xs font-bold uppercase ml-2 mb-1 block">Costo Unitario ($)</label>
                            <input 
                                type="number" 
                                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white font-bold text-lg focus:border-green-500 outline-none"
                                value={formData.cost}
                                onChange={e => updatePrice(e.target.value, formData.margin)}
                            />
                        </div>

                        <div>
                            <div className="flex justify-between mb-1 ml-2">
                                <label className="text-slate-400 text-xs font-bold uppercase block">Margen de Ganancia (%)</label>
                                <span className="text-green-400 text-xs font-bold">{formData.margin}%</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" max="100" step="0.5"
                                className="w-full accent-green-500 h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                                value={formData.margin}
                                onChange={e => updatePrice(formData.cost, e.target.value)}
                            />
                        </div>

                        <div className="pt-4 border-t border-white/10">
                            <label className="text-slate-300 text-sm font-bold uppercase block text-center mb-2">Precio Público Sugerido</label>
                            <div className="bg-white text-slate-900 p-4 rounded-2xl text-center shadow-lg transform scale-105">
                                <span className="text-3xl font-black">${formData.price.toFixed(2)}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Placeholder de Imagen */}
                <div className="bg-slate-50 p-8 rounded-[2.5rem] border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:bg-slate-100 hover:border-slate-400 transition-colors cursor-pointer min-h-[200px]">
                    <ImageIcon size={48} className="mb-2" />
                    <span className="font-bold text-sm">Subir Imagen del Producto</span>
                    <span className="text-xs mt-1">(Click para explorar)</span>
                </div>

                {/* Botón Guardar */}
                <button 
                    onClick={handleSave}
                    disabled={loading}
                    className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-bold text-lg shadow-lg shadow-indigo-600/30 hover:bg-indigo-700 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex justify-center items-center gap-3"
                >
                    {loading ? (
                        <span className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></span>
                    ) : (
                        <>
                            <Save size={24} /> 
                            {mode === 'create' ? 'Registrar Producto' : 'Guardar Cambios'}
                        </>
                    )}
                </button>

            </div>
        </div>
      </div>
    </div>
  );
}