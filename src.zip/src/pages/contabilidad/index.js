// src/pages/contabilidad/index.js
export { default as CambioPrecio } from './CambioPrecio';
export { default as AltaCliente } from './AltaCliente';
export { default as Contpaq } from './Contpaq';
export { default as Hardware} from './Hardware';