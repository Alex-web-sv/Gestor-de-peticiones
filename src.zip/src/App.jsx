
import { Suspense, lazy } from "react";
import { Routes, Route } from "react-router-dom";
import Sidebar from "./components/sidebar"; 
import PageLayout from "./components/PageLayout";
import ProtectedRoute from "./routes/ProtectedRoute";
import { ROLES } from "./config/menuconfig";

// =========================================================================
// 1. LAZY IMPORTS (Carga bajo demanda para velocidad)
// =========================================================================

// --- COMPARTIDOS (La mayoría viene de aquí) ---
const AltaCliente = lazy(() => import("./pages/compartido/AltaCliente"));
const CambioPrecio = lazy(() => import("./pages/compartido/CambioPrecio"));
const Hardware = lazy(() => import("./pages/compartido/Hardware"));
const ProductForm = lazy(() => import("./pages/compartido/ModificacionProducto"));
const BankMovements = lazy(() => import("./pages/compartido/BankMovements"));
const DeleteReceipts = lazy(() => import("./pages/compartido/DeleteReceipts"));
const InventoryOperations = lazy(() => import("./pages/compartido/InventoryOperations")); // La Navaja Suiza
const GenericRequest = lazy(() => import("./pages/compartido/GenericRequest")); // Solicitudes

// --- ESPECÍFICOS DE CONTABILIDAD ---
const Contpaq = lazy(() => import("./pages/contabilidad/Contpaq"));

// --- PLACEHOLDER (Para lo que falta desarrollar) ---
const Placeholder = ({ title }) => (
  <div className="flex flex-col items-center justify-center h-64 border-2 border-dashed border-slate-300 rounded-[2.5rem] bg-slate-50">
    <span className="text-4xl mb-2">🚧</span>
    <p className="text-slate-500 font-bold text-lg">Módulo: {title}</p>
    <p className="text-sm text-slate-400">En desarrollo / Pendiente de asignar</p>
  </div>
);

function App() {
  // CONFIGURACIÓN DE USUARIO (SIMULACIÓN)
  // Cambia esto para probar diferentes vistas: ROLES.BANCAS, ROLES.MOSTRADOR, etc.
  const currentUser = {
    name: "Alejandro",
    role: ROLES.ADMIN
  };

  return (
    <div className="flex min-h-screen bg-[#f1f5f9]">
      
      <Sidebar role={currentUser.role} user={currentUser.name} />

      <main className="flex-1 p-6 md:p-8 overflow-y-auto h-screen">
        <Suspense fallback={
            <div className="flex items-center justify-center h-full text-orange-600 font-bold animate-pulse">
                Cargando módulo...
            </div>
        }>
          <Routes>
            
            <Route path="/" element={
                <div className="bg-white p-10 rounded-[2.5rem] shadow-sm">
                    <h1 className="text-3xl font-bold text-slate-800">Bienvenido, {currentUser.name}</h1>
                    <p className="text-slate-500 mt-2">Panel de Usuario: {currentUser.role}</p>
                </div>
            } />

            {/* ===============================================================
                DEPARTAMENTO: CONTABILIDAD
               =============================================================== */}
            <Route element={<ProtectedRoute isAllowed={[ROLES.ADMIN, ROLES.CONTABILIDAD].includes(currentUser.role)} />}>
                <Route path="/contabilidad/cambio-precio" element={<PageLayout title="Cambio de Precios"><CambioPrecio /></PageLayout>} />
                <Route path="/contabilidad/alta-cliente" element={<PageLayout title="Gestión de Clientes"><AltaCliente /></PageLayout>} />
                <Route path="/contabilidad/contpaq" element={<PageLayout title="Enlace Contpaq"><Contpaq /></PageLayout>} />
                <Route path="/contabilidad/hardware" element={<PageLayout title="Recursos IT"><Hardware /></PageLayout>} />
            </Route>

            {/* ===============================================================
                DEPARTAMENTO: BANCAS
               =============================================================== */}
             {/* Nota: Revisa si tu carpeta es 'bancas' o 'bancos' en el navConfig. Aquí uso '/bancas/' */}
            <Route path="/bancas/mov-bancarios" element={<PageLayout title="Movimientos Bancarios"><BankMovements /></PageLayout>} />
            <Route path="/bancas/recibos" element={<PageLayout title="Eliminar Recibos"><DeleteReceipts /></PageLayout>} />
            <Route path="/bancas/EliminarOrdenes" element={<PageLayout title="Eliminar Órdenes de Pago"><DeleteReceipts /></PageLayout>} /> {/* Reutilizado */}
            
            <Route path="/bancas/AltaConceptos" element={<PageLayout title="Conceptos Bancarios"><Placeholder title="Catálogo Conceptos" /></PageLayout>} />
            <Route path="/bancas/AltaCajas" element={<PageLayout title="Alta de Cajas"><Placeholder title="Catálogo Cajas" /></PageLayout>} />
            <Route path="/bancas/Hardware" element={<PageLayout title="Hardware y Software"><Hardware /></PageLayout>} />
            
            <Route path="/bancas/alta-cliente" element={<PageLayout title="Gestion de Clientes"><AltaCliente /></PageLayout>} />
            <Route path="/bancas/alta-producto" element={<PageLayout title="Gestión de Productos"><ProductForm /></PageLayout>} />
            <Route path="/bancas/cambio-precio" element={<PageLayout title="Cambio de Precios"><CambioPrecio /></PageLayout>} />

            {/* Solicitudes Bancas */}
            <Route path="/bancas/PagosGeneral" element={<PageLayout title="Solicitud: Pagos"><GenericRequest title="Pagos en General" /></PageLayout>} />
            <Route path="/bancas/ValidacionNomina" element={<PageLayout title="Solicitud: Nómina"><GenericRequest title="Validación de Nómina" /></PageLayout>} />


            {/* ===============================================================
                DEPARTAMENTO: ADM. CAJA
               =============================================================== */}
            <Route path="/admincaja/Remisiones" element={<PageLayout title="Remisiones"><Placeholder title="Gestión Remisiones" /></PageLayout>} />
            <Route path="/admincaja/MovBancarios" element={<PageLayout title="Mov. Bancarios (Caja)"><BankMovements /></PageLayout>} />
            <Route path="/admincaja/alta-cliente" element={<PageLayout title="gestion de Clientes"><AltaCliente /></PageLayout>} />
            <Route path="/admincaja/ModificacionPrecios" element={<PageLayout title="Precios (Caja)"><CambioPrecio /></PageLayout>} />
            
            <Route path="/admincaja/CuadreFacturas" element={<PageLayout title="Cuadre Facturas"><Placeholder title="Cuadre" /></PageLayout>} />
            <Route path="/admincaja/CancelacionFacturas" element={<PageLayout title="Cancelar Facturas"><Placeholder title="Facturación" /></PageLayout>} />
            <Route path="/admincaja/EliminacionRecibos" element={<PageLayout title="Eliminar Recibos"><DeleteReceipts /></PageLayout>} />
            <Route path="/admincaja/CancelacionCartera" element={<PageLayout title="Cancelar Cartera"><Placeholder title="Cartera" /></PageLayout>} />
            <Route path="/admincaja/CerrarPedido" element={<PageLayout title="Cierre de Pedidos"><Placeholder title="Pedidos" /></PageLayout>} />
            <Route path="/admincaja/hardware" element={<PageLayout title="Hardware (Caja)"><Hardware /></PageLayout>} />

            {/* Solicitudes Adm Caja (Usando GenericRequest) */}
            <Route path="/admincaja/PagosProveedores" element={<PageLayout title="Pagos"><GenericRequest title="Pago a Proveedores" /></PageLayout>} />
            <Route path="/admincaja/SolicitudGas" element={<PageLayout title="Combustible"><GenericRequest title="Solicitud de Gas/Combustible" /></PageLayout>} />
            <Route path="/admincaja/PagosServicios" element={<PageLayout title="Servicios"><GenericRequest title="Pago de Servicios" /></PageLayout>} />
            <Route path="/admincaja/Reembolsos" element={<PageLayout title="Reembolsos"><GenericRequest title="Solicitud de Reembolso" /></PageLayout>} />
            <Route path="/admincaja/NotasCargo" element={<PageLayout title="Notas C/C"><GenericRequest title="Notas de Cargo/Crédito" /></PageLayout>} />
            <Route path="/admincaja/BonosHonorarios" element={<PageLayout title="Bonos"><GenericRequest title="Pago de Bonos/Honorarios" /></PageLayout>} />
            <Route path="/admincaja/RemisionesManuales" element={<PageLayout title="Remisiones"><GenericRequest title="Solicitud Remisión Manual" /></PageLayout>} />


            {/* ===============================================================
                DEPARTAMENTO: MOSTRADOR
               =============================================================== */}
            <Route path="/mostrador/alta-cliente" element={<PageLayout title="Gestion de Clientes"><AltaCliente /></PageLayout>} />
            <Route path="/mostrador/cambio-precio" element={<PageLayout title="Cambio de Precios"><CambioPrecio /></PageLayout>} />
            <Route path="/mostrador/AltaProveedor" element={<PageLayout title="Alta Proveedor"><AltaCliente /></PageLayout>} /> {/* Reutilizamos AltaCliente o creamos uno nuevo luego */}
            <Route path="/mostrador/alta-producto" element={<PageLayout title="Alta Productos"><ProductForm /></PageLayout>} />
            
            {/* OPERACIONES DE INVENTARIO (Usando la Navaja Suiza) */}
            <Route path="/mostrador/Traspasos" element={<PageLayout title="Traspasos"><InventoryOperations title="Traspaso de Mercancía" type="traspaso" /></PageLayout>} />
            <Route path="/mostrador/AjustesInventario" element={<PageLayout title="Ajustes"><InventoryOperations title="Ajuste de Inventario" type="ajuste" /></PageLayout>} />
            <Route path="/mostrador/AjustesFerreteria" element={<PageLayout title="Ajustes Ferretería"><InventoryOperations title="Ajuste Sensibles/Ferretería" type="ajuste" /></PageLayout>} />
            <Route path="/mostrador/EntradaCompra" element={<PageLayout title="Entrada Compra"><InventoryOperations title="Recepción de Compra" type="compra" /></PageLayout>} />
            
            <Route path="/mostrador/CerrarPedido" element={<PageLayout title="Cerrar Pedido"><Placeholder title="Cierre de Pedidos" /></PageLayout>} />
            
            {/* Solicitudes Mostrador */}
            <Route path="/mostrador/BajaMerma" element={<PageLayout title="Mermas"><InventoryOperations title="Solicitud Baja por Merma" type="merma" /></PageLayout>} />
            <Route path="/mostrador/SalidaPedidos" element={<PageLayout title="Salida Crédito"><GenericRequest title="Salida Pedidos Crédito" /></PageLayout>} />
            <Route path="/mostrador/TransferenciaSaldo" element={<PageLayout title="Saldos"><GenericRequest title="Transferencia de Saldos" /></PageLayout>} />
            <Route path="/mostrador/Compras" element={<PageLayout title="Compras"><GenericRequest title="Solicitud de Compra" /></PageLayout>} />
            <Route path="/mostrador/Validacion" element={<PageLayout title="Validación"><GenericRequest title="Validación/Aplicación de Saldos" /></PageLayout>} />


            {/* ===============================================================
                DEPARTAMENTO: GERENTE
               =============================================================== */}
            <Route path="/gerente/cambio-precio" element={<PageLayout title="Cambio de Precios"><CambioPrecio /></PageLayout>} />
            
            {/* Operaciones Gerente */}
            <Route path="/gerente/Traspasos" element={<PageLayout title="Traspasos"><InventoryOperations title="Autorizar Traspasos" type="traspaso" /></PageLayout>} />
            <Route path="/gerente/AjustesInventario" element={<PageLayout title="Ajustes"><InventoryOperations title="Ajustes de Inventario" type="ajuste" /></PageLayout>} />
            <Route path="/gerente/AjustesFerreteria" element={<PageLayout title="Ajustes Sensibles"><InventoryOperations title="Ajuste Ferretería" type="ajuste" /></PageLayout>} />
            <Route path="/gerente/EntradaCompra" element={<PageLayout title="Compras"><InventoryOperations title="Entrada de Compra" type="compra" /></PageLayout>} />
            <Route path="/gerente/BajaMerma" element={<PageLayout title="Mermas"><InventoryOperations title="Autorización de Mermas" type="merma" /></PageLayout>} />

            {/* Solicitudes Gerente */}
            <Route path="/gerente/PrecioSugerido" element={<PageLayout title="Precios"><GenericRequest title="Cambio de Precio Sugerido" /></PageLayout>} />
            <Route path="/gerente/SalidaPedido" element={<PageLayout title="Crédito"><GenericRequest title="Salida Pedidos Crédito" /></PageLayout>} />
            <Route path="/gerente/TransferenciaSaldo" element={<PageLayout title="Saldos"><GenericRequest title="Transferencia de Saldos" /></PageLayout>} />
            <Route path="/gerente/ValidacionSaldo" element={<PageLayout title="Validación"><GenericRequest title="Validación de Saldos" /></PageLayout>} />
            <Route path="/gerente/SolicitudGas" element={<PageLayout title="Combustible"><GenericRequest title="Solicitud Gas/Combustible" /></PageLayout>} />
            <Route path="/gerente/SolicitudUnidadesPDV" element={<PageLayout title="Gastos"><GenericRequest title="Gastos Unidades/PDV" /></PageLayout>} />
            <Route path="/gerente/Compras" element={<PageLayout title="Compras"><GenericRequest title="Solicitud de Compras" /></PageLayout>} />


            {/* ===============================================================
                DEPARTAMENTO: PATIO
               =============================================================== */}
            <Route path="/patio/AjustesInventario" element={<PageLayout title="Ajustes (Patio)"><InventoryOperations title="Ajuste de Inventario" type="ajuste" /></PageLayout>} />
            <Route path="/patio/EntradaCompra" element={<PageLayout title="Recepción"><InventoryOperations title="Entrada de Compra" type="compra" /></PageLayout>} />
            <Route path="/patio/RecetasProduccion" element={<PageLayout title="Producción"><InventoryOperations title="Receta de Producción" type="produccion" /></PageLayout>} />
            <Route path="/patio/Traspasos" element={<PageLayout title="Traspasos"><InventoryOperations title="Traspaso de Material" type="traspaso" /></PageLayout>} />
            
            {/* Solicitudes Patio */}
            <Route path="/patio/BajaMerma" element={<PageLayout title="Mermas"><InventoryOperations title="Reporte de Merma/Uso Interno" type="merma" /></PageLayout>} />
            <Route path="/patio/SolicitudGas" element={<PageLayout title="Combustible"><GenericRequest title="Solicitud Gas/Combustible" /></PageLayout>} />
            <Route path="/patio/CartaPorte" element={<PageLayout title="Carta Porte"><GenericRequest title="Solicitud Carta Porte" /></PageLayout>} />
            <Route path="/patio/GastosUnidades" element={<PageLayout title="Gastos"><GenericRequest title="Gastos de Unidades" /></PageLayout>} />


            {/* 404 */}
            <Route path="*" element={<div className="p-10 text-slate-400 font-bold">Página no encontrada.</div>} />

          </Routes>
        </Suspense>
      </main>
    </div>
  );
}

export default App;