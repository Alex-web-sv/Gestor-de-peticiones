
// src/config/menuconfig.js
import { 
  Calculator, Landmark, Users, Briefcase, 
  ShoppingBag, Truck, LifeBuoy, FileText 
} from 'lucide-react';

export const ROLES = {
  ADMIN: 'admin',
  CONTABILIDAD: 'contabilidad',
  BANCAS: 'bancas',
  CAJA: 'admincaja', 
  MOSTRADOR: 'mostrador',
  GERENTE: 'gerente',
  PATIO: 'patio'
};

/* NOTA IMPORTANTE:
   Todas las rutas deben coincidir EXACTAMENTE con las definidas en App.jsx.
   Usamos el formato: /departamento/accion (todo minúsculas)
*/

export const navConfig = [
  // =========================================================
  // 1. CONTABILIDAD
  // =========================================================
  {
    label: 'contabilidad',
    icon: Calculator,
    roles: [ROLES.ADMIN, ROLES.CONTABILIDAD],
    submenus: [
      {
        label: 'Soporte',
        icon: LifeBuoy,
        items: [
          { path: '/contabilidad/cambio-precio', label: 'Cambio de Precio' },
          { path: '/contabilidad/alta-cliente', label: 'Alta/Modif. Cliente' },
          { path: '/contabilidad/contpaq', label: 'Contpaq' },
          { path: '/contabilidad/hardware', label: 'Hardware/Software' },
        ]
      }
    ]
  },

  // =========================================================
  // 2. BANCAS
  // =========================================================
  {
    label: 'bancas',
    icon: Landmark,
    roles: [ROLES.ADMIN, ROLES.BANCAS],
    submenus: [
      {
        label: 'Soporte',
        icon: FileText,
        items: [
          { path: '/bancas/mov-bancarios', label: 'Elim./Mod. Mov. Bancarios' },
          { path: '/bancas/recibos', label: 'Eliminar Recibos' },
          { path: '/bancas/ordenes', label: 'Eliminar Órdenes Pago' },
          { path: '/bancas/conceptos', label: 'Alta de Conceptos Bancarios' },
          { path: '/bancas/cajas', label: 'Alta de Cajas' },
          { path: '/bancas/hardware', label: 'Hardware/Software' },
          { path: '/bancas/alta-cliente', label: 'Alta/Modificación de Clientes' },
          { path: '/bancas/alta-producto', label: 'Alta/Modificación de Productos' },
          { path: '/bancas/cambio-precio', label: 'Cambios de Precio' }, 
        ]
      },
      {
        label: 'Solicitudes',
        icon: LifeBuoy,
        items: [
          { path: '/bancas/pagos-general', label: 'Pagos en General' },
          { path: '/bancas/validacion-nomina', label: 'Validación de Nómina' }, 
        ]
      }
    ]
  },

  // =========================================================
  // 3. ADMIN CAJA
  // =========================================================
  {
    label: 'admincaja',
    icon: Briefcase,
    roles: [ROLES.ADMIN, ROLES.CAJA],
    submenus: [
      {
        label: 'Soporte',
        icon: FileText,
        items: [
          { path: "/admincaja/remisiones", label: "Cancelación Remisiones" },
          { path: "/admincaja/mov-bancarios", label: "Movimientos Bancarios" },
          { path: "/admincaja/alta-cliente", label: "Alta/Modif. Cliente" },
          { path: "/admincaja/cambio-precio", label: "Modificación de Precios" }, // Estandarizado
          { path: "/admincaja/cuadre-facturas", label: "Cuadre de Facturas" },
          { path: "/admincaja/cancelacion-facturas", label: "Cancelación de Facturas" },
          { path: "/admincaja/recibos", label: "Eliminación Recibos" },
          { path: "/admincaja/cartera", label: "Cancelación de Cartera" },
          { path: "/admincaja/cerrar-pedidos", label: "Cerrar Pedidos (Frentes)" },
          { path: "/admincaja/hardware", label: "Hardware/Software" },
        ]
      },
      {
        label: 'Solicitudes',
        icon: LifeBuoy,
        items: [
          { path: "/admincaja/pagos-proveedores", label: "Pagos a Proveedores" },
          { path: "/admincaja/solicitud-gas", label: "Solicitud de Gas" },
          { path: "/admincaja/pagos-servicios", label: "Pagos de Servicios" },
          { path: "/admincaja/reembolsos", label: "Reembolsos Variados" },
          { path: "/admincaja/notas-cargo", label: "Notas de Cargo/Crédito" },
          { path: "/admincaja/pagos-bonos", label: "Pagos Bonos/Honorarios" },
          { path: "/admincaja/reembolso-efectivo", label: "Reembolso Efectivo" },
          { path: "/admincaja/remisiones-manual", label: "Remisiones Manuales" },
        ]
      }
    ]
  },
   
  // =========================================================
  // 4. MOSTRADOR
  // =========================================================
  {
    label: 'mostrador',
    icon: ShoppingBag,
    roles: [ROLES.ADMIN, ROLES.MOSTRADOR], // CORREGIDO: Antes decía CAJA
    submenus: [
      {
        label: 'Soporte',
        icon: FileText,
        items: [
          { path: "/mostrador/alta-cliente", label: "Alta/Modif. Cliente" },
          { path: "/mostrador/cambio-precio", label: "Cambio de Precio" },
          { path: "/mostrador/alta-proveedor", label: "Alta Proveedor" },
          { path: "/mostrador/alta-producto", label: "Alta/Modif. Producto" },
          { path: "/mostrador/traspasos", label: "Traspasos" },
          { path: "/mostrador/ajustes-inventario", label: "Ajustes de Inventario" },
          { path: "/mostrador/cruce-ferreteria", label: "Cruce/Ajustes Ferretería" },
          { path: "/mostrador/cerrar-pedidos", label: "Cerrar Pedidos" },
          { path: "/mostrador/entrada-compra", label: "Entrada de Compra" },
        ]
      },
      {
        label: 'Solicitudes',
        icon: LifeBuoy,
        items: [
          { path: "/mostrador/baja-merma", label: "Baja Merma/Uso Interno" },
          { path: "/mostrador/precio-sugerido", label: "Precio Sugerido" },
          { path: "/mostrador/salida-pedidos", label: "Salida Pedidos Crédito" },
          { path: "/mostrador/transferencia-saldos", label: "Transferencia Saldos" },
          { path: "/mostrador/compras", label: "Compras" },
          { path: "/mostrador/validacion-saldos", label: "Validación de Saldos" },
        ]
      }
    ]
  },

  // =========================================================
  // 5. GERENTE
  // =========================================================
  {
    label: 'gerente',
    icon: Users,
    roles: [ROLES.ADMIN, ROLES.GERENTE], // CORREGIDO: Antes decía CAJA
    submenus: [
      {
        label: 'Soporte',
        icon: FileText,
        items: [
          { path: "/gerente/cambio-precio", label: "Cambio de Precio" },
          { path: "/gerente/traspasos", label: "Traspasos" },
          { path: "/gerente/ajustes-inventario", label: "Ajustes de Inventario" },
          { path: "/gerente/cruce-ferreteria", label: "Cruce Ferretería" },
          { path: "/gerente/entrada-compra", label: "Entrada de Compra" },
        ]
      },
      {
        label: 'Solicitudes',
        icon: LifeBuoy,
        items: [
          { path: "/gerente/baja-merma", label: "Baja Merma" },
          { path: "/gerente/precio-sugerido", label: "Precio Sugerido" },
          { path: "/gerente/salida-pedidos", label: "Salida Pedidos Crédito" },
          { path: "/gerente/transferencia-saldos", label: "Transferencia Saldos" },
          { path: "/gerente/validacion-saldos", label: "Validación Saldos" },
          { path: "/gerente/solicitud-gas", label: "Solicitud Gas" },
          { path: "/gerente/solicitud-carte-porte", label: "Solicitud Carta Porte" },
          { path: "/gerente/solicitud-gastos", label: "Gastos Unidades/PDV" },
          { path: "/gerente/compras", label: "Compras" },
        ]
      }
    ]
  },

  // =========================================================
  // 6. PATIO
  // =========================================================
  {
    label: 'patio',
    icon: Truck,
    roles: [ROLES.ADMIN, ROLES.PATIO], // CORREGIDO: Antes decía CAJA
    submenus: [
      {
        label: 'Soporte',
        icon: FileText,
        items: [
          { path: "/patio/ajustes-inventario", label: "Ajustes de Inventario" },
          { path: "/patio/entrada-compra", label: "Entrada de Compra" },
          { path: "/patio/recetas-produccion", label: "Recetas de Producción" },
          { path: "/patio/traspasos", label: "Traspasos" },
        ]
      },
      {
        label: 'Solicitudes',
        icon: LifeBuoy,
        items: [
          { path: "/patio/baja-merma", label: "Baja Merma" },
          { path: "/patio/solicitud-gas", label: "Solicitud Gas" },
          { path: "/patio/solicitud-carte-porte", label: "Solicitud Carta Porte" },
          { path: "/patio/solicitud-gastos", label: "Gastos Unidades" },
        ]
      }
    ]
  }
];