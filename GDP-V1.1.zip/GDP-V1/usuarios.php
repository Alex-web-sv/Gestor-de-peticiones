<?php
session_start();

// Verificar si hay sesión activa
if (!isset($_SESSION['usuario'])) {
    header('Location: index.php'); // redirige al login si no hay sesión
    exit;
}

// Si el usuario es administrador, redirigirlo a su panel
if ($_SESSION['rol'] === 'ADM. SISTEMA') {
    header('Location: administrador.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuario</title>
</head>

<body>
    <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?></h1>
    <p>Tu rol es: <?php echo htmlspecialchars($_SESSION['rol']); ?></p>

    <a href="logout.php">Cerrar sesión</a>
</body>

</html>