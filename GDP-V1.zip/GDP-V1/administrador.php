<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php');
    exit;
}

if ($_SESSION['rol'] !== 'ADM. SISTEMA') {
    header('Location: usuarios.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Panel Admin - Pedidos,- Clientes, Reportes, Configuración</title>
    <link rel="stylesheet" href="build/css/app.css" />
</head>

<body>
    <div class="app">
        <aside class="sidebar" aria-label="Navegación principal">
            <div class="brand">
                <div class="logo">PA</div>
                <div class="brand-text">Panel Admin</div>
            </div>

            <ul class="menu" id="menuSidebar" role="menu">
                <li data-section="pedidos" class="activo" role="menuitem" tabindex="0">Pedidos</li>
                <li data-section="clientes" role="menuitem" tabindex="0">Clientes</li>
                <li data-section="reportes" role="menuitem" tabindex="0">Reportes</li>
                <li data-section="configuracion" role="menuitem" tabindex="0">Configuración</li>
            </ul>
            <div class="btn-div-salir">
                <a class="btn-salir" href="index.php">SALIR</a>
            </div>

            <div class="sidebar-footer">
                <div class="small">Usuario: <strong>Alejandro</strong></div>
            </div>
        </aside>

        <main class="workspace" id="workspace" role="main"></main>
    </div>
    <script src="build/js/administrador.min.js"></script>
</body>

</html>