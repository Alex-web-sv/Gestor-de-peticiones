import path from 'path';
import fs from 'fs';
import { glob } from 'glob';
import { src, dest, watch, series } from 'gulp';
import * as dartSass from 'sass';
import gulpSass from 'gulp-sass';
import terser from 'gulp-terser';
import sharp from 'sharp';
import sourcemaps from 'gulp-sourcemaps';
import rename from 'gulp-rename';

const sass = gulpSass(dartSass);

// ✅ Compilar cada archivo JS por separado
export function js() {
  return src('src/js/**/*.js', { sourcemaps: true })
    .pipe(sourcemaps.init())
    .pipe(terser())
    .pipe(rename({ suffix: '.min' }))
    .pipe(sourcemaps.write('.'))
    .pipe(dest('build/js'));
}

export function css() {
  return src('src/scss/app.scss', { sourcemaps: true })
    .pipe(sass({ style: 'compressed' }).on('error', sass.logError))
    .pipe(dest('build/css', { sourcemaps: '.' }));
}

export async function imagenes(done) {
  const srcDir = './src/img';
  const buildDir = './build/img';
  const images = await glob('./src/img/**/*{jpg,png}');

  images.forEach(file => {
    const relativePath = path.relative(srcDir, path.dirname(file));
    const outputSubDir = path.join(buildDir, relativePath);
    procesarImagenes(file, outputSubDir);
  });
  done();
}

function procesarImagenes(file, outputSubDir) {
  if (!fs.existsSync(outputSubDir)) {
    fs.mkdirSync(outputSubDir, { recursive: true });
  }
  const baseName = path.basename(file, path.extname(file));
  const extName = path.extname(file);
  const outputFile = path.join(outputSubDir, `${baseName}${extName}`);
  const outputFileWebp = path.join(outputSubDir, `${baseName}.webp`);
  const outputFileAvif = path.join(outputSubDir, `${baseName}.avif`);

  const options = { quality: 80 };
  sharp(file).jpeg(options).toFile(outputFile);
  sharp(file).webp(options).toFile(outputFileWebp);
  sharp(file).avif().toFile(outputFileAvif);
}

export function dev() {
  watch('src/scss/**/*.scss', css);
  watch('src/js/**/*.js', js);
  watch('src/img/**/*.{png,jpg}', imagenes);
}

export default series(js, css, imagenes, dev);
